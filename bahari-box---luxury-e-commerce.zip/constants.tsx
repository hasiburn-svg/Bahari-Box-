
import { Product, Order } from './types';

export const CATEGORIES = ['Artisanal', 'Wellness', 'Sanctuary', 'Tech', 'Confectionery'];

export const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'The Midnight Bloom artisanal Box',
    description: 'A hand-curated selection of rare midnight-blooming tea and a stone-carved infuser.',
    price: 3450.00,
    category: 'Artisanal',
    stock: 12,
    image: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&q=80&w=800',
    featured: true,
  },
  {
    id: '2',
    name: 'Nordic Slate Wellness Set',
    description: 'Minimalist spa essentials including organic volcanic salt scrub and cedarwood oil.',
    price: 2800.00,
    category: 'Wellness',
    stock: 15,
    image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&q=80&w=800',
    featured: true,
  },
  {
    id: '3',
    name: 'Ethereal Glass Decanter',
    description: 'Hand-blown crystalline glass decanter with a solid brass stopper.',
    price: 5200.50,
    category: 'Sanctuary',
    stock: 5,
    image: 'https://images.unsplash.com/photo-1516594915697-87eb3b1c14ea?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: '4',
    name: 'Sonic Bamboo Speaker',
    description: 'Sustainable bamboo housing with high-fidelity acoustic performance.',
    price: 8900.00,
    category: 'Tech',
    stock: 8,
    image: 'https://images.unsplash.com/photo-1544652478-6653e09f18a2?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: '5',
    name: 'Truffle Honey Pairing Kit',
    description: 'Wildflower honey infused with black winter truffles and gold-plated spreader.',
    price: 1850.00,
    category: 'Confectionery',
    stock: 30,
    image: 'https://images.unsplash.com/photo-1566311651474-56b72a420b79?auto=format&fit=crop&q=80&w=800',
  }
];

export const MOCK_ORDERS: Order[] = [
  {
    id: 'ORD-7721',
    customerName: 'Sarah Jenkins',
    customerEmail: 's.jenkins@luxury.co',
    total: 6250.00,
    status: 'Delivered',
    date: '2023-12-15',
    items: [
      { productId: '1', name: 'The Midnight Bloom artisanal Box', quantity: 1, price: 3450.00 },
      { productId: '2', name: 'Nordic Slate Wellness Set', quantity: 1, price: 2800.00 }
    ]
  },
  {
    id: 'ORD-7722',
    customerName: 'Marcus Thorne',
    customerEmail: 'mthorne@global.net',
    total: 5200.50,
    status: 'Shipped',
    date: '2023-12-18',
    items: [
      { productId: '3', name: 'Ethereal Glass Decanter', quantity: 1, price: 5200.50 }
    ]
  }
];
