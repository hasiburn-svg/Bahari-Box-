# Bahari Box — The Art of Gifting

Bahari Box is a world-class, modern E-commerce platform and Admin Dashboard curated for artisanal excellence. This project is built with a focus on high-end aesthetics, local market integration (Bangladesh), and seamless user experience.

## ✨ Features

### 🛍️ Public Storefront
- **Editorial Homepage**: Featuring the signature "Unwrap Thoughtfulness" hero section.
- **Artisanal Catalog**: Filterable products with high-fidelity image galleries.
- **Localized Checkout**: Integrated with Bangladeshi payment gateways (**bKash**, **Nagad**, **Rocket**, **NexusPay**, and Cards).
- **The Bahari Circle**: A private member area for customers to track their curated collections.

### 🛡️ Merchant Control Center
- **Dynamic Dashboard**: Real-time sales analytics using Recharts.
- **Inventory Control**: AI-assisted product descriptions powered by Google Gemini.
- **Logistics Ledger**: Comprehensive order management with transaction verification.
- **Global Settings**: Site-wide controls including maintenance mode and announcement broadcasts.

## 🛠️ Tech Stack
- **Framework**: React 19 / Vite / React Router 7
- **Styling**: Tailwind CSS (Custom Luxury Theme)
- **Icons**: Lucide React
- **Analytics**: Recharts
- **AI**: @google/genai (Gemini 3 Flash)
- **Storage**: Context API + LocalStorage Persistence

## 🚀 Getting Started
1. Clone the repository.
2. Open `index.html` in a modern browser (using a local server like Live Server).
3. Set your `API_KEY` in the environment for AI features.

## 🇧🇩 Localized for Bangladesh
- Currency: **BDT (৳)**
- Payment Gateways: Fully simulated MFS (Mobile Financial Services) flows.
- Shipping: Localized for major cities like Dhaka, Chittagong, and Sylhet.

---
*Curated in Excellence — 2024*
