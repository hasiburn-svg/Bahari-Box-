
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { StoreProvider } from './store';
import { PublicLayout, AdminLayout } from './components/Layout';
import Home from './pages/Home';
import Products from './pages/Products';
import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import AdminDashboard from './pages/AdminDashboard';
import AdminProducts from './pages/AdminProducts';
import AdminOrders from './pages/AdminOrders';
import AdminSettings from './pages/AdminSettings';
import AdminLogin from './pages/AdminLogin';
import CustomerLogin from './pages/CustomerLogin';
import CustomerDashboard from './pages/CustomerDashboard';

// Auth Guard Component
const ProtectedRoute = ({ children, isAuthenticated, redirectPath = "/admin/login" }: { children: React.ReactNode, isAuthenticated: boolean, redirectPath?: string }) => {
  if (!isAuthenticated) {
    return <Navigate to={redirectPath} replace />;
  }
  return <>{children}</>;
};

const App: React.FC = () => {
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(() => {
    return localStorage.getItem('isAdminAuthenticated') === 'true';
  });

  const handleLogin = () => {
    setIsAdminAuthenticated(true);
    localStorage.setItem('isAdminAuthenticated', 'true');
  };

  const handleLogout = () => {
    setIsAdminAuthenticated(false);
    localStorage.removeItem('isAdminAuthenticated');
  };

  return (
    <StoreProvider>
      <Router>
        <Routes>
          {/* Public Storefront Routes */}
          <Route path="/" element={<PublicLayout><Home /></PublicLayout>} />
          <Route path="/products" element={<PublicLayout><Products /></PublicLayout>} />
          <Route path="/product/:id" element={<PublicLayout><ProductDetail /></PublicLayout>} />
          <Route path="/cart" element={<PublicLayout><Cart /></PublicLayout>} />
          <Route path="/checkout" element={<PublicLayout><Checkout /></PublicLayout>} />
          
          {/* Customer Specific Routes */}
          <Route path="/login" element={<CustomerLogin />} />
          <Route path="/account" element={<PublicLayout><CustomerDashboard /></PublicLayout>} />

          {/* Admin Auth Route */}
          <Route path="/admin/login" element={<AdminLogin onLogin={handleLogin} isAuthenticated={isAdminAuthenticated} />} />

          {/* Protected Admin Routes */}
          <Route path="/admin" element={
            <ProtectedRoute isAuthenticated={isAdminAuthenticated}>
              <AdminLayout onLogout={handleLogout}><AdminDashboard /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/admin/products" element={
            <ProtectedRoute isAuthenticated={isAdminAuthenticated}>
              <AdminLayout onLogout={handleLogout}><AdminProducts /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/admin/orders" element={
            <ProtectedRoute isAuthenticated={isAdminAuthenticated}>
              <AdminLayout onLogout={handleLogout}><AdminOrders /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/admin/settings" element={
            <ProtectedRoute isAuthenticated={isAdminAuthenticated}>
              <AdminLayout onLogout={handleLogout}><AdminSettings /></AdminLayout>
            </ProtectedRoute>
          } />
          <Route path="/admin/customers" element={
            <ProtectedRoute isAuthenticated={isAdminAuthenticated}>
              <AdminLayout onLogout={handleLogout}>
                <div className="text-center py-12 text-slate-500">Customer profiles management coming soon.</div>
              </AdminLayout>
            </ProtectedRoute>
          } />

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </StoreProvider>
  );
};

export default App;
