
import React, { useState } from 'react';
import { Navigate, Link } from 'react-router-dom';
import { Button, Input, Card } from '../components/UI';
import { Lock, ShieldCheck, ArrowLeft, Loader2 } from 'lucide-react';
import { Logo } from '../components/Layout';

interface AdminLoginProps {
  onLogin: () => void;
  isAuthenticated: boolean;
}

const AdminLogin: React.FC<AdminLoginProps> = ({ onLogin, isAuthenticated }) => {
  const [loading, setLoading] = useState(false);
  const [credentials, setCredentials] = useState({ email: '', password: '' });

  if (isAuthenticated) {
    return <Navigate to="/admin" replace />;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      onLogin();
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-primary flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Abstract Background Elements */}
      <div className="absolute top-[-10%] right-[-10%] w-96 h-96 bg-accent/20 rounded-full blur-[120px]"></div>
      <div className="absolute bottom-[-10%] left-[-10%] w-96 h-96 bg-white/5 rounded-full blur-[100px]"></div>

      <div className="w-full max-w-md relative z-10 space-y-8">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center justify-center p-3 bg-white/5 rounded-2xl border border-white/10 mb-2">
            <Logo className="w-12 h-12" color="#FFFFFF" />
          </div>
          <h1 className="font-brand text-4xl font-bold text-white italic">Merchant Portal</h1>
          <p className="text-white/40 text-xs font-bold uppercase tracking-[0.4em]">Secure Access Required</p>
        </div>

        <Card className="p-8 bg-white/5 border-white/10 backdrop-blur-xl shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-white/50 block">Administrator ID</label>
              <Input 
                type="email" 
                required 
                placeholder="curator@baharibox.com" 
                className="bg-white/5 border-white/10 text-white placeholder:text-white/20 focus:ring-accent/50 h-12"
                value={credentials.email}
                onChange={e => setCredentials({...credentials, email: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-white/50 block">Access Key</label>
              <Input 
                type="password" 
                required 
                placeholder="••••••••" 
                className="bg-white/5 border-white/10 text-white placeholder:text-white/20 focus:ring-accent/50 h-12"
                value={credentials.password}
                onChange={e => setCredentials({...credentials, password: e.target.value})}
              />
            </div>
            
            <Button 
              type="submit" 
              className="w-full h-12 bg-white text-primary hover:bg-accent hover:text-white transition-all font-black uppercase tracking-widest text-[10px]"
              disabled={loading}
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <><ShieldCheck className="w-4 h-4" /> Grant Entry</>}
            </Button>
          </form>

          <div className="mt-8 pt-8 border-t border-white/5 text-center">
            <div className="flex items-center justify-center gap-2 text-white/30 text-[10px] font-bold uppercase tracking-widest">
              <Lock className="w-3 h-3" /> Encrypted Session
            </div>
          </div>
        </Card>

        <Link to="/" className="flex items-center justify-center gap-2 text-white/40 hover:text-white transition-colors text-xs font-bold uppercase tracking-widest group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back to Storefront
        </Link>
      </div>

      <p className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/20 text-[8px] font-black uppercase tracking-[0.5em]">
        Bahari Box Curator System v2.4.0
      </p>
    </div>
  );
};

export default AdminLogin;
