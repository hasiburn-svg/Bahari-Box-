
import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { Button, Badge, Card } from '../components/UI';
import { 
  ShoppingBag, Heart, Share2, ShieldCheck, 
  Truck, RotateCcw, Star, ChevronRight, 
  Minus, Plus, Check, ArrowLeft
} from 'lucide-react';
import { ProductCard } from './Home';

const ProductDetail: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { products, addToCart } = useStore();
  const [quantity, setQuantity] = useState(1);
  const [isAdded, setIsAdded] = useState(false);
  const [activeTab, setActiveTab] = useState<'description' | 'shipping' | 'reviews'>('description');

  const product = products.find(p => p.id === id);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  if (!product) {
    return (
      <div className="py-40 text-center">
        <h2 className="text-3xl font-brand font-bold mb-4">Item Not Found</h2>
        <Link to="/products" className="text-accent underline">Return to Catalog</Link>
      </div>
    );
  }

  const relatedProducts = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <div className="bg-white min-h-screen pb-24">
      {/* Breadcrumbs */}
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-8">
        <nav className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-400">
          <Link to="/" className="hover:text-primary transition-colors">Home</Link>
          <ChevronRight className="w-3 h-3" />
          <Link to="/products" className="hover:text-primary transition-colors">Catalog</Link>
          <ChevronRight className="w-3 h-3" />
          <span className="text-primary">{product.category}</span>
        </nav>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-12 grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24">
        {/* Product Images */}
        <div className="space-y-6">
          <div className="aspect-[4/5] bg-slate-50 overflow-hidden relative group">
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            {product.featured && (
              <div className="absolute top-8 left-8">
                <Badge variant="default" className="bg-white/90 backdrop-blur-md px-4 py-2 text-[10px] font-black uppercase tracking-[0.2em]">Exclusive Curation</Badge>
              </div>
            )}
          </div>
          <div className="grid grid-cols-4 gap-4">
             {[1, 2, 3, 4].map(i => (
               <div key={i} className="aspect-square bg-slate-50 cursor-pointer hover:opacity-80 transition-opacity border border-transparent hover:border-accent">
                 <img src={product.image} className="w-full h-full object-cover" alt="" />
               </div>
             ))}
          </div>
        </div>

        {/* Product Info */}
        <div className="flex flex-col">
          <div className="mb-10 space-y-4">
            <p className="text-xs font-black uppercase tracking-[0.4em] text-accent">{product.category}</p>
            <h1 className="font-brand text-4xl lg:text-6xl font-bold text-primary leading-tight">{product.name}</h1>
            <div className="flex items-center gap-6">
              <p className="text-2xl font-light text-primary">৳{product.price.toLocaleString()}</p>
              <div className="flex items-center gap-1 text-accent">
                {[1,2,3,4,5].map(i => <Star key={i} className="w-3.5 h-3.5 fill-current" />)}
                <span className="text-[10px] font-black text-slate-400 ml-2 uppercase tracking-widest">12 Reviews</span>
              </div>
            </div>
          </div>

          <p className="text-slate-500 leading-relaxed font-light text-lg mb-10 italic">
            "{product.description}"
          </p>

          <div className="space-y-10 pb-12 border-b border-slate-100 mb-10">
            {/* Quantity Selector */}
            <div className="space-y-4">
              <label className="text-[10px] font-black uppercase tracking-widest text-primary">Quantity</label>
              <div className="flex items-center gap-4">
                <div className="flex items-center border border-slate-200 bg-white">
                  <button 
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-12 h-12 flex items-center justify-center text-slate-400 hover:text-primary transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-12 text-center font-bold text-sm">{quantity}</span>
                  <button 
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-12 h-12 flex items-center justify-center text-slate-400 hover:text-primary transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={handleAddToCart}
                className={`flex-grow h-16 text-xs font-black uppercase tracking-[0.2em] shadow-2xl transition-all duration-500 ${isAdded ? 'bg-green-600 border-green-600' : 'bg-primary border-none hover:bg-slate-900'}`}
              >
                {isAdded ? (
                  <><Check className="w-5 h-5" /> Added to Your Box</>
                ) : (
                  <><ShoppingBag className="w-5 h-5" /> Curate to Box</>
                )}
              </Button>
              <button className="w-16 h-16 border border-slate-200 flex items-center justify-center text-slate-400 hover:text-red-500 hover:border-red-500 transition-all group">
                <Heart className="w-6 h-6 group-hover:fill-current" />
              </button>
              <button className="w-16 h-16 border border-slate-200 flex items-center justify-center text-slate-400 hover:text-primary hover:border-primary transition-all">
                <Share2 className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Value Props */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-12">
             <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-primary">
                   <Truck className="w-5 h-5" />
                </div>
                <div>
                   <h4 className="text-[10px] font-black uppercase tracking-widest text-primary mb-1">Priority Delivery</h4>
                   <p className="text-xs text-slate-400 font-light">Complimentary on orders over ৳1,500.</p>
                </div>
             </div>
             <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-primary">
                   <RotateCcw className="w-5 h-5" />
                </div>
                <div>
                   <h4 className="text-[10px] font-black uppercase tracking-widest text-primary mb-1">30-Day Curated Return</h4>
                   <p className="text-xs text-slate-400 font-light">Bespoke returns for your peace of mind.</p>
                </div>
             </div>
          </div>

          {/* Tabs */}
          <div className="space-y-6">
             <div className="flex border-b border-slate-100">
                {(['description', 'shipping', 'reviews'] as const).map(tab => (
                  <button 
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`pb-4 px-6 text-[10px] font-black uppercase tracking-widest transition-all relative ${activeTab === tab ? 'text-primary' : 'text-slate-300 hover:text-slate-500'}`}
                  >
                    {tab}
                    {activeTab === tab && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-accent"></div>}
                  </button>
                ))}
             </div>
             <div className="py-4 animate-in fade-in duration-500">
                {activeTab === 'description' && (
                  <div className="space-y-4 text-slate-500 text-sm font-light leading-relaxed">
                     <p>Each {product.name} is a testament to the artisan's dedication to perfection. We source the components from three continents to ensure that the sensory experience of unboxing is nothing short of transcendent.</p>
                     <ul className="list-disc pl-5 space-y-2">
                        <li>Hand-finished aesthetic detailing.</li>
                        <li>Sourced from verified independent artisans.</li>
                        <li>Limited run, high-integrity craftsmanship.</li>
                        <li>Ethical packaging materials.</li>
                     </ul>
                  </div>
                )}
                {activeTab === 'shipping' && (
                  <p className="text-slate-500 text-sm font-light leading-relaxed">
                    Standard shipping takes 3-5 business days. Express overnight is available at checkout for urban areas. All boxes are climate-controlled during transit to ensure the integrity of the artisanal contents.
                  </p>
                )}
                {activeTab === 'reviews' && (
                  <div className="space-y-6">
                    <div className="flex items-center gap-4 bg-slate-50 p-6 rounded-sm">
                       <span className="text-4xl font-brand font-bold text-primary">4.8</span>
                       <div className="space-y-1">
                          <div className="flex text-accent">
                             {[1,2,3,4,5].map(i => <Star key={i} className="w-3 h-3 fill-current" />)}
                          </div>
                          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Based on 12 reviews</p>
                       </div>
                    </div>
                  </div>
                )}
             </div>
          </div>
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <section className="mt-40 border-t border-slate-50 pt-24">
          <div className="max-w-7xl mx-auto px-6 lg:px-12">
            <div className="flex justify-between items-baseline mb-16">
               <h2 className="font-brand text-4xl font-bold text-primary italic">You may also desire</h2>
               <Link to="/products" className="text-[10px] font-black uppercase tracking-[0.3em] text-accent">View All</Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
               {relatedProducts.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        </section>
      )}
    </div>
  );
};

export default ProductDetail;
