
import React, { useState, useMemo } from 'react';
import { useStore } from '../store';
import { CATEGORIES } from '../constants';
import { ProductCard } from './Home';
import { Search, SlidersHorizontal, ChevronDown, LayoutGrid, List } from 'lucide-react';
import { Input } from '../components/UI';

const Products: React.FC = () => {
  const { products } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortOrder, setSortOrder] = useState<'featured' | 'low-high' | 'high-low'>('featured');

  const filteredProducts = useMemo(() => {
    return products
      .filter(p => {
        const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                             p.description.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
        return matchesSearch && matchesCategory;
      })
      .sort((a, b) => {
        if (sortOrder === 'low-high') return a.price - b.price;
        if (sortOrder === 'high-low') return b.price - a.price;
        return (a.featured ? -1 : 1) - (b.featured ? -1 : 1);
      });
  }, [products, searchTerm, selectedCategory, sortOrder]);

  return (
    <div className="bg-white min-h-screen">
      {/* Editorial Header */}
      <section className="bg-[#F1EFEC] py-24 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto flex flex-col items-center text-center">
           <span className="text-[10px] font-black uppercase tracking-[0.5em] text-secondary mb-4">Discover</span>
           <h1 className="font-brand text-5xl lg:text-7xl font-bold text-primary mb-6">The Catalog</h1>
           <p className="text-slate-500 max-w-xl font-light italic leading-relaxed">
             "Our curated selection of artisanal goods, hand-picked for quality, aesthetic, and the pure joy of unboxing."
           </p>
        </div>
      </section>

      {/* Filter & Sort Bar */}
      <section className="sticky top-20 z-40 bg-white/90 backdrop-blur-md border-b border-slate-100 px-6 lg:px-12 py-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex flex-wrap items-center justify-center gap-2">
            <button 
              onClick={() => setSelectedCategory('All')}
              className={`px-5 py-2 text-[10px] font-black uppercase tracking-widest rounded-none transition-all ${selectedCategory === 'All' ? 'bg-primary text-white' : 'hover:bg-slate-50 text-slate-400'}`}
            >
              All
            </button>
            {CATEGORIES.map(cat => (
              <button 
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2 text-[10px] font-black uppercase tracking-widest rounded-none transition-all ${selectedCategory === cat ? 'bg-primary text-white' : 'hover:bg-slate-50 text-slate-400'}`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-6 w-full md:w-auto">
             <div className="relative flex-grow md:flex-initial">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-3.5 h-3.5" />
                <input 
                  type="text" 
                  placeholder="Search the collection..." 
                  className="pl-9 pr-4 py-2 border-b border-slate-200 text-xs focus:outline-none focus:border-primary w-full transition-all bg-transparent placeholder:text-slate-300 font-medium"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
             </div>
             <div className="flex items-center gap-2 group cursor-pointer relative">
                <SlidersHorizontal className="w-4 h-4 text-slate-400" />
                <select 
                  className="appearance-none bg-transparent text-[10px] font-black uppercase tracking-widest text-slate-600 outline-none pr-4"
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value as any)}
                >
                  <option value="featured">Sort: Featured</option>
                  <option value="low-high">Price: Low to High</option>
                  <option value="high-low">Price: High to Low</option>
                </select>
                <ChevronDown className="w-3 h-3 text-slate-400 absolute right-0 top-1/2 -translate-y-1/2 pointer-events-none" />
             </div>
          </div>
        </div>
      </section>

      {/* Grid */}
      <section className="py-24 px-6 lg:px-12">
        <div className="max-w-7xl mx-auto">
           {filteredProducts.length > 0 ? (
             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-20">
               {filteredProducts.map(product => <ProductCard key={product.id} product={product} />)}
             </div>
           ) : (
             <div className="py-40 text-center space-y-6">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto opacity-50">
                   <Search className="w-8 h-8 text-slate-300" />
                </div>
                <h3 className="font-brand text-2xl font-bold text-slate-900">No treasures found</h3>
                <p className="text-slate-500 max-w-xs mx-auto text-sm font-light">We couldn't find any products matching your current selection. Try a different category or search term.</p>
                <button onClick={() => { setSearchTerm(''); setSelectedCategory('All'); }} className="text-[10px] font-black uppercase tracking-widest text-primary underline underline-offset-8 decoration-1">Reset all filters</button>
             </div>
           )}
        </div>
      </section>
    </div>
  );
};

export default Products;
