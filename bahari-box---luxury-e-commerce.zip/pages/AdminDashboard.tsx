
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';
import { Card, Badge, Button, Input } from '../components/UI';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, Cell } from 'recharts';
import { 
  DollarSign, ShoppingCart, Package, TrendingUp, 
  Users, ArrowUpRight, ArrowDownRight, Clock,
  ChevronRight, Calendar, Zap, Globe, ShieldAlert,
  Megaphone, MousePointer2
} from 'lucide-react';

const DashboardStats: React.FC<{ 
  label: string; 
  value: string; 
  icon: any; 
  trend: string;
  isPositive: boolean;
  color: string;
}> = ({ label, value, icon: Icon, trend, isPositive, color }) => (
  <Card className="p-8 border-none bg-white shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_20px_50px_rgba(0,0,0,0.08)] transition-all duration-500 group relative overflow-hidden">
    <div className={`absolute top-0 right-0 w-24 h-24 ${color} opacity-[0.03] rounded-bl-full transform translate-x-8 -translate-y-8 group-hover:scale-150 transition-transform duration-700`}></div>
    <div className="flex justify-between items-start relative z-10">
      <div className={`p-4 rounded-2xl ${color} bg-opacity-10 text-primary mb-6 shadow-inner`}>
        <Icon className="w-6 h-6" />
      </div>
      <div className={`flex items-center gap-1.5 text-[11px] font-black px-3 py-1.5 rounded-full ${isPositive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
        {isPositive ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
        {trend}
      </div>
    </div>
    <div className="relative z-10">
      <h4 className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] mb-1">{label}</h4>
      <p className="text-3xl font-black text-slate-900 tracking-tight">{value}</p>
    </div>
  </Card>
);

const AdminDashboard: React.FC = () => {
  const { getDashboardStats, orders, siteSettings, updateSiteSettings } = useStore();
  const stats = getDashboardStats();
  const [announcement, setAnnouncement] = useState(siteSettings.announcementBar);

  const handleUpdateAnnouncement = () => {
    updateSiteSettings({ announcementBar: announcement });
  };

  const recentOrders = orders.slice(0, 5);

  return (
    <div className="space-y-12">
      {/* Header with Master Control Entry */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-8">
        <div>
          <h1 className="text-4xl font-brand font-bold text-slate-900 mb-2 italic">Command Center Overview</h1>
          <p className="text-slate-500 font-medium">System status: <span className="text-green-500 font-black uppercase tracking-widest text-[10px]">Operational</span> • Active Users: 142</p>
        </div>
        <div className="flex flex-wrap gap-4">
           <Button variant="outline" className="h-14 px-8 bg-white border-none shadow-sm text-xs font-black uppercase tracking-widest rounded-2xl">
             <Calendar className="w-4 h-4 mr-3 text-accent" /> Custom Range
           </Button>
           <Button className="h-14 px-10 bg-primary text-white text-xs font-black uppercase tracking-widest rounded-2xl shadow-2xl shadow-primary/20 hover:scale-105 transition-transform">
             <Zap className="w-4 h-4 mr-3 text-accent" /> Dynamic Report
           </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        <DashboardStats label="Gross Revenue" value={`৳${stats.totalSales.toLocaleString()}`} icon={DollarSign} trend="+18.4%" isPositive={true} color="bg-emerald-500" />
        <DashboardStats label="Order Volume" value={stats.totalOrders.toString()} icon={ShoppingCart} trend="+4.2%" isPositive={true} color="bg-blue-500" />
        <DashboardStats label="Inventory Value" value="৳4.2M" icon={Package} trend="-2.1%" isPositive={false} color="bg-orange-500" />
        <DashboardStats label="Site Conversion" value="3.84%" icon={MousePointer2} trend="+1.2%" isPositive={true} color="bg-purple-500" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-12">
        {/* Analytics Section */}
        <Card className="xl:col-span-2 border-none shadow-xl shadow-slate-200/50 bg-white overflow-hidden rounded-[2.5rem]">
          <div className="p-10 border-b border-slate-50 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="space-y-1">
               <h3 className="text-xl font-black text-slate-900 flex items-center gap-3">
                 <TrendingUp className="w-6 h-6 text-accent" /> Revenue Flux
               </h3>
               <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">7-Day Transactional Flow</p>
            </div>
            <div className="flex bg-slate-100 p-1.5 rounded-2xl">
              {['Weekly', 'Monthly', 'Yearly'].map((t, i) => (
                <button key={t} className={`px-6 py-2.5 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${i === 0 ? 'bg-white text-primary shadow-md' : 'text-slate-400 hover:text-slate-600'}`}>
                  {t}
                </button>
              ))}
            </div>
          </div>
          <div className="p-10 h-[500px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.recentSales}>
                <defs>
                  <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#C5A059" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#C5A059" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="6 6" vertical={false} stroke="#F1F5F9" />
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#94A3B8', fontSize: 11, fontWeight: 800}} dy={15} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94A3B8', fontSize: 11, fontWeight: 800}} dx={-15} />
                <Tooltip 
                  contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.15)', padding: '20px' }}
                  itemStyle={{ color: '#2A1B28', fontWeight: '900', fontSize: '14px' }}
                />
                <Area type="monotone" dataKey="amount" stroke="#C5A059" strokeWidth={5} fillOpacity={1} fill="url(#revenueGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Master Control Panel */}
        <div className="space-y-8">
           <Card className="p-8 bg-primary text-white rounded-[2.5rem] relative overflow-hidden shadow-2xl shadow-primary/30">
              <div className="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full blur-3xl -translate-y-12 translate-x-12"></div>
              <h3 className="text-xl font-black mb-6 flex items-center gap-3">
                 <Zap className="w-6 h-6 text-accent" /> Master Controls
              </h3>
              <div className="space-y-6">
                 <div className="p-6 bg-white/5 rounded-3xl border border-white/10 space-y-4">
                    <div className="flex items-center justify-between">
                       <span className="text-xs font-black uppercase tracking-widest text-white/50">Maintenance Mode</span>
                       <button 
                         onClick={() => updateSiteSettings({ isMaintenanceMode: !siteSettings.isMaintenanceMode })}
                         className={`w-12 h-6 rounded-full transition-all relative ${siteSettings.isMaintenanceMode ? 'bg-red-500' : 'bg-slate-700'}`}
                       >
                         <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${siteSettings.isMaintenanceMode ? 'left-7' : 'left-1'}`}></div>
                       </button>
                    </div>
                    <p className="text-[10px] text-white/30 font-medium">Instantly put the public storefront into 'Updating' status.</p>
                 </div>

                 <div className="space-y-3">
                    <label className="text-xs font-black uppercase tracking-widest text-white/50">Announcement Broadcast</label>
                    <div className="relative">
                       <Megaphone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-accent" />
                       <Input 
                         value={announcement}
                         onChange={e => setAnnouncement(e.target.value)}
                         className="bg-white/5 border-white/10 text-white pl-12 h-12 rounded-2xl text-xs placeholder:text-white/20"
                         placeholder="New site banner text..."
                       />
                    </div>
                    <Button 
                      onClick={handleUpdateAnnouncement}
                      className="w-full h-12 bg-accent text-white border-none rounded-2xl text-[10px] font-black uppercase tracking-widest"
                    >
                      Sync Broadcast
                    </Button>
                 </div>
              </div>
           </Card>

           <Card className="p-8 bg-white rounded-[2.5rem] shadow-xl shadow-slate-200/50">
              <h3 className="text-lg font-black text-slate-900 mb-6 flex items-center justify-between">
                 Activity Log
                 <Badge className="bg-slate-100 text-slate-500 border-none font-black text-[9px]">Live</Badge>
              </h3>
              <div className="space-y-6">
                 {recentOrders.map((order, i) => (
                   <div key={order.id} className="flex gap-4 items-center group cursor-pointer">
                      <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center font-black text-primary border border-slate-100 group-hover:bg-primary group-hover:text-white transition-all">
                         {order.customerName.charAt(0)}
                      </div>
                      <div className="flex-grow min-w-0">
                         <p className="text-sm font-black text-slate-900 truncate">৳{order.total.toLocaleString()}</p>
                         <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">By {order.customerName}</p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-200 group-hover:text-primary transition-colors" />
                   </div>
                 ))}
              </div>
              <Button variant="ghost" className="w-full mt-10 py-4 bg-slate-50 hover:bg-slate-100 rounded-2xl text-[10px] font-black uppercase tracking-widest">
                Comprehensive Audit
              </Button>
           </Card>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
