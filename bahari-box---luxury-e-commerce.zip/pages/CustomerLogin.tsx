
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useStore } from '../store';
import { Button, Input, Card } from '../components/UI';
import { Mail, Lock, ArrowRight, ArrowLeft, Loader2, Sparkles } from 'lucide-react';
import { Logo } from '../components/Layout';

const CustomerLogin: React.FC = () => {
  const navigate = useNavigate();
  const { customerLogin } = useStore();
  const [loading, setLoading] = useState(false);
  const [isSignup, setIsSignup] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    password: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulated Auth
    setTimeout(() => {
      customerLogin(formData.email, formData.name || 'Artisan Guest');
      setLoading(false);
      navigate('/account');
    }, 1200);
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Visual Panel */}
      <div className="hidden lg:block w-1/2 relative overflow-hidden bg-primary">
        <img 
          src="https://images.unsplash.com/photo-1513201099705-a9746e1e201f?auto=format&fit=crop&q=80&w=2000" 
          className="w-full h-full object-cover opacity-60 mix-blend-overlay"
          alt="Luxury Packaging"
        />
        <div className="absolute inset-0 p-24 flex flex-col justify-between">
           <Logo className="w-16 h-16" color="white" />
           <div className="space-y-6 max-w-lg">
              <span className="text-accent text-[10px] font-black uppercase tracking-[0.6em]">The Bahari Circle</span>
              <h1 className="font-brand text-6xl text-white font-bold leading-tight italic">Step into a world of curated treasures.</h1>
              <p className="text-white/60 text-lg font-light leading-relaxed">
                Join our circle for priority access to artisanal collections and a personalized gifting history.
              </p>
           </div>
           <p className="text-white/30 text-[9px] font-black uppercase tracking-[0.5em]">Curated in Excellence — 2024</p>
        </div>
      </div>

      {/* Right Form Panel */}
      <div className="w-full lg:w-1/2 bg-[#FCFBFC] flex items-center justify-center p-8 sm:p-24 relative">
        <Link to="/" className="absolute top-12 left-12 lg:left-24 flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-300 hover:text-primary transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Store
        </Link>

        <div className="w-full max-w-md space-y-12">
          <div className="space-y-4">
             <h2 className="font-brand text-4xl font-bold text-primary">{isSignup ? 'Create Your Account' : 'Welcome Back'}</h2>
             <p className="text-slate-500 font-light italic">
                {isSignup ? 'Join our community of thoughtful curators today.' : 'Please enter your details to access your circle profile.'}
             </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {isSignup && (
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Full Name</label>
                <div className="relative">
                  <Input 
                    required 
                    placeholder="Evelyn V." 
                    className="h-14 pl-4 border-slate-200 rounded-none bg-white focus:ring-1 focus:ring-accent"
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                  />
                </div>
              </div>
            )}
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Email Address</label>
              <div className="relative">
                <Input 
                  required 
                  type="email" 
                  placeholder="name@email.com" 
                  className="h-14 pl-4 border-slate-200 rounded-none bg-white focus:ring-1 focus:ring-accent"
                  value={formData.email}
                  onChange={e => setFormData({...formData, email: e.target.value})}
                />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-end">
                <label className="text-[10px] font-black uppercase tracking-widest text-slate-400">Security Key</label>
                {!isSignup && <button type="button" className="text-[9px] font-black text-accent uppercase tracking-widest">Forgot?</button>}
              </div>
              <div className="relative">
                <Input 
                  required 
                  type="password" 
                  placeholder="••••••••" 
                  className="h-14 pl-4 border-slate-200 rounded-none bg-white focus:ring-1 focus:ring-accent"
                  value={formData.password}
                  onChange={e => setFormData({...formData, password: e.target.value})}
                />
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full h-14 bg-primary text-white border-none rounded-none text-[10px] font-black uppercase tracking-[0.3em] shadow-2xl hover:bg-accent transition-all"
              disabled={loading}
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <>{isSignup ? 'Join The Circle' : 'Access Profile'} <ArrowRight className="w-4 h-4 ml-3" /></>}
            </Button>
          </form>

          <div className="space-y-6 pt-6 text-center">
             <div className="relative flex items-center gap-4">
                <div className="h-[1px] bg-slate-100 flex-grow"></div>
                <span className="text-[9px] font-black uppercase tracking-widest text-slate-300">Or</span>
                <div className="h-[1px] bg-slate-100 flex-grow"></div>
             </div>

             <p className="text-xs text-slate-500 font-light">
                {isSignup ? 'Already have an account?' : "Don't have an account yet?"}{' '}
                <button 
                  onClick={() => setIsSignup(!isSignup)} 
                  className="text-primary font-bold underline underline-offset-4 decoration-accent/30 hover:decoration-accent transition-all"
                >
                  {isSignup ? 'Sign in instead' : 'Join the circle'}
                </button>
             </p>

             <Link to="/" className="inline-block text-[10px] font-black uppercase tracking-widest text-slate-300 hover:text-primary transition-colors">
               Continue as Guest
             </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomerLogin;
