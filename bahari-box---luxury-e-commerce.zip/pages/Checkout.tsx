
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useStore } from '../store';
import { Button, Input, Card, Badge } from '../components/UI';
import { 
  CreditCard, ShieldCheck, CheckCircle, 
  ChevronRight, Lock, Loader2, Smartphone,
  Check, ArrowLeft, Info, Fingerprint
} from 'lucide-react';

type PaymentMethod = 'card' | 'bkash' | 'nagad' | 'rocket' | 'upay';

const Checkout: React.FC = () => {
  const navigate = useNavigate();
  const { cart, placeOrder, siteSettings } = useStore();
  const [step, setStep] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [mfsStep, setMfsStep] = useState<'number' | 'otp' | 'pin'>('number');
  const [orderId, setOrderId] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('bkash');
  const [txId, setTxId] = useState('');

  const [shippingInfo, setShippingInfo] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: 'Dhaka',
    zip: ''
  });

  const [mfsNumber, setMfsNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [pin, setPin] = useState('');

  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const total = subtotal + (subtotal >= siteSettings.freeShippingThreshold ? 0 : 150);

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2);
  };

  const handleMfsFlow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (mfsStep === 'number') {
      setIsProcessing(true);
      setTimeout(() => {
        setIsProcessing(false);
        setMfsStep('otp');
      }, 1500);
    } else if (mfsStep === 'otp') {
      setIsProcessing(true);
      setTimeout(() => {
        setIsProcessing(false);
        setMfsStep('pin');
      }, 1200);
    } else {
      handleFinalizeOrder();
    }
  };

  const handleFinalizeOrder = async () => {
    setIsProcessing(true);
    // Generate a mock transaction ID like real gateways
    const generatedTxId = Math.random().toString(36).substring(2, 10).toUpperCase();
    setTxId(generatedTxId);

    // Simulate bank verification
    await new Promise(resolve => setTimeout(resolve, 3000));

    const id = placeOrder({ name: shippingInfo.name, email: shippingInfo.email }, total, paymentMethod.toUpperCase(), generatedTxId);
    setOrderId(id);
    setIsProcessing(false);
    setStep(3);
  };

  const getBrandColor = () => {
    switch(paymentMethod) {
      case 'bkash': return '#D12053';
      case 'nagad': return '#F37021';
      case 'rocket': return '#8C3494';
      case 'upay': return '#103674';
      default: return '#2A1B28';
    }
  };

  if (cart.length === 0 && step !== 3) {
    return (
      <div className="max-w-7xl mx-auto px-6 lg:px-12 py-32 text-center">
        <h2 className="font-brand text-3xl font-bold mb-6 text-primary">Your box is currently empty</h2>
        <Link to="/products"><Button className="px-12 h-14 bg-primary text-white text-[10px] font-black uppercase tracking-widest">Discover Treasures</Button></Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-6 lg:px-12 py-16">
      {/* Progress Path */}
      <div className="flex items-center justify-center mb-20">
        <div className="flex items-center gap-6">
          <div className="flex flex-col items-center gap-2">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center font-black text-xs transition-all ${step >= 1 ? 'bg-primary text-white shadow-xl shadow-primary/20' : 'bg-slate-100 text-slate-400'}`}>1</div>
            <span className="text-[8px] font-black uppercase tracking-widest text-slate-400">Identity</span>
          </div>
          <div className={`w-20 h-[2px] mb-6 rounded transition-all ${step >= 2 ? 'bg-primary' : 'bg-slate-100'}`}></div>
          <div className="flex flex-col items-center gap-2">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center font-black text-xs transition-all ${step >= 2 ? 'bg-primary text-white shadow-xl shadow-primary/20' : 'bg-slate-100 text-slate-400'}`}>2</div>
            <span className="text-[8px] font-black uppercase tracking-widest text-slate-400">Payment</span>
          </div>
          <div className={`w-20 h-[2px] mb-6 rounded transition-all ${step >= 3 ? 'bg-primary' : 'bg-slate-100'}`}></div>
          <div className="flex flex-col items-center gap-2">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center font-black text-xs transition-all ${step >= 3 ? 'bg-primary text-white shadow-xl shadow-primary/20' : 'bg-slate-100 text-slate-400'}`}>3</div>
            <span className="text-[8px] font-black uppercase tracking-widest text-slate-400">Success</span>
          </div>
        </div>
      </div>

      {step === 1 && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
          <div className="lg:col-span-7 space-y-12">
            <div className="space-y-4">
              <h2 className="font-brand text-4xl font-bold text-primary italic">Delivery Logistics</h2>
              <p className="text-slate-500 font-light italic">Please provide the destination for your curated treasures.</p>
            </div>

            <form onSubmit={handleNextStep} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Full Name</label>
                  <Input required placeholder="Evelyn V." value={shippingInfo.name} onChange={e => setShippingInfo({...shippingInfo, name: e.target.value})} className="h-14 border-slate-200 focus:ring-accent rounded-none bg-white" />
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Email Address</label>
                  <Input required type="email" placeholder="e.v@example.com" value={shippingInfo.email} onChange={e => setShippingInfo({...shippingInfo, email: e.target.value})} className="h-14 border-slate-200 focus:ring-accent rounded-none bg-white" />
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Contact Number</label>
                  <Input required placeholder="01XXXXXXXXX" value={shippingInfo.phone} onChange={e => setShippingInfo({...shippingInfo, phone: e.target.value})} className="h-14 border-slate-200 focus:ring-accent rounded-none bg-white" />
                </div>
                <div className="md:col-span-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Street Address</label>
                  <Input required placeholder="House 12, Road 4, Banani" value={shippingInfo.address} onChange={e => setShippingInfo({...shippingInfo, address: e.target.value})} className="h-14 border-slate-200 focus:ring-accent rounded-none bg-white" />
                </div>
                <div>
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">City</label>
                   <select 
                     className="w-full h-14 px-4 border border-slate-200 focus:ring-1 focus:ring-accent outline-none text-sm font-medium bg-white"
                     value={shippingInfo.city}
                     onChange={e => setShippingInfo({...shippingInfo, city: e.target.value})}
                   >
                     <option>Dhaka</option>
                     <option>Chittagong</option>
                     <option>Sylhet</option>
                     <option>Rajshahi</option>
                     <option>Khulna</option>
                   </select>
                </div>
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">ZIP Code</label>
                  <Input required placeholder="1213" value={shippingInfo.zip} onChange={e => setShippingInfo({...shippingInfo, zip: e.target.value})} className="h-14 border-slate-200 focus:ring-accent rounded-none bg-white" />
                </div>
              </div>
              <Button type="submit" className="w-full h-16 bg-primary text-white text-[10px] font-black uppercase tracking-[0.4em] shadow-2xl shadow-primary/20 hover:bg-accent transition-all">
                Proceed to Payment <ChevronRight className="ml-2 w-4 h-4" />
              </Button>
            </form>
          </div>

          <div className="lg:col-span-5">
            <Card className="p-10 bg-[#F1EFEC] border-none rounded-[2.5rem] sticky top-32">
              <h3 className="font-brand font-bold text-2xl text-primary mb-8">Box Summary</h3>
              <div className="space-y-6 mb-10 max-h-60 overflow-y-auto pr-4 custom-scrollbar">
                {cart.map(item => (
                  <div key={item.id} className="flex justify-between items-center gap-4">
                    <div className="flex items-center gap-4">
                       <div className="w-12 h-12 bg-white rounded-xl overflow-hidden flex-shrink-0">
                          <img src={item.image} className="w-full h-full object-cover" alt="" />
                       </div>
                       <div>
                          <p className="text-xs font-bold text-primary leading-tight">{item.name}</p>
                          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{item.quantity} units</p>
                       </div>
                    </div>
                    <span className="text-sm font-bold text-primary">৳{(item.price * item.quantity).toLocaleString()}</span>
                  </div>
                ))}
              </div>
              <div className="space-y-4 pt-8 border-t border-slate-200">
                 <div className="flex justify-between text-xs font-bold text-slate-500 uppercase tracking-widest">
                    <span>Subtotal</span>
                    <span>৳{subtotal.toLocaleString()}</span>
                 </div>
                 <div className="flex justify-between text-xs font-bold text-slate-500 uppercase tracking-widest">
                    <span>Shipping</span>
                    <span>{subtotal >= siteSettings.freeShippingThreshold ? 'Complimentary' : `৳150`}</span>
                 </div>
                 <div className="flex justify-between pt-4 border-t border-slate-900">
                    <span className="font-brand font-bold text-2xl text-primary">Total</span>
                    <span className="font-brand font-bold text-2xl text-accent">৳{total.toLocaleString()}</span>
                 </div>
              </div>
            </Card>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="max-w-3xl mx-auto space-y-12">
          <div className="text-center space-y-4">
            <h2 className="font-brand text-4xl font-bold text-primary italic">Select Payment Essence</h2>
            <p className="text-slate-500 font-light flex items-center justify-center gap-2 text-sm italic">
              <Lock className="w-4 h-4 text-green-500" /> Secure transactional gateway for Bangladeshi Banks.
            </p>
          </div>
          
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
            <button onClick={() => setPaymentMethod('bkash')} className={`p-6 rounded-3xl border-2 flex flex-col items-center justify-center gap-3 transition-all relative ${paymentMethod === 'bkash' ? 'border-[#D12053] bg-[#D12053]/5 shadow-xl' : 'border-slate-50 hover:border-slate-200 bg-white'}`}>
              <div className="w-10 h-10 bg-[#D12053] rounded-2xl flex items-center justify-center text-white text-[14px] font-black italic tracking-tighter">b</div>
              <span className={`text-[10px] font-black uppercase tracking-widest ${paymentMethod === 'bkash' ? 'text-[#D12053]' : 'text-slate-400'}`}>bKash</span>
              {paymentMethod === 'bkash' && <div className="absolute top-3 right-3 text-[#D12053]"><Check className="w-4 h-4" /></div>}
            </button>
            <button onClick={() => setPaymentMethod('nagad')} className={`p-6 rounded-3xl border-2 flex flex-col items-center justify-center gap-3 transition-all relative ${paymentMethod === 'nagad' ? 'border-[#F37021] bg-[#F37021]/5 shadow-xl' : 'border-slate-50 hover:border-slate-200 bg-white'}`}>
              <div className="w-10 h-10 bg-[#F37021] rounded-2xl flex items-center justify-center text-white text-[14px] font-black italic tracking-tighter">n</div>
              <span className={`text-[10px] font-black uppercase tracking-widest ${paymentMethod === 'nagad' ? 'text-[#F37021]' : 'text-slate-400'}`}>Nagad</span>
              {paymentMethod === 'nagad' && <div className="absolute top-3 right-3 text-[#F37021]"><Check className="w-4 h-4" /></div>}
            </button>
            <button onClick={() => setPaymentMethod('rocket')} className={`p-6 rounded-3xl border-2 flex flex-col items-center justify-center gap-3 transition-all relative ${paymentMethod === 'rocket' ? 'border-[#8C3494] bg-[#8C3494]/5 shadow-xl' : 'border-slate-50 hover:border-slate-200 bg-white'}`}>
              <div className="w-10 h-10 bg-[#8C3494] rounded-2xl flex items-center justify-center text-white text-[14px] font-black italic tracking-tighter">R</div>
              <span className={`text-[10px] font-black uppercase tracking-widest ${paymentMethod === 'rocket' ? 'text-[#8C3494]' : 'text-slate-400'}`}>Rocket</span>
              {paymentMethod === 'rocket' && <div className="absolute top-3 right-3 text-[#8C3494]"><Check className="w-4 h-4" /></div>}
            </button>
            <button onClick={() => setPaymentMethod('upay')} className={`p-6 rounded-3xl border-2 flex flex-col items-center justify-center gap-3 transition-all relative ${paymentMethod === 'upay' ? 'border-[#103674] bg-[#103674]/5 shadow-xl' : 'border-slate-50 hover:border-slate-200 bg-white'}`}>
              <div className="w-10 h-10 bg-[#103674] rounded-2xl flex items-center justify-center text-white text-[14px] font-black italic tracking-tighter">u</div>
              <span className={`text-[10px] font-black uppercase tracking-widest ${paymentMethod === 'upay' ? 'text-[#103674]' : 'text-slate-400'}`}>Upay</span>
              {paymentMethod === 'upay' && <div className="absolute top-3 right-3 text-[#103674]"><Check className="w-4 h-4" /></div>}
            </button>
            <button onClick={() => setPaymentMethod('card')} className={`p-6 rounded-3xl border-2 flex flex-col items-center justify-center gap-3 transition-all relative ${paymentMethod === 'card' ? 'border-primary bg-primary/5 shadow-xl' : 'border-slate-50 hover:border-slate-200 bg-white'}`}>
              <CreditCard className={`w-10 h-10 ${paymentMethod === 'card' ? 'text-primary' : 'text-slate-400'}`} />
              <span className={`text-[10px] font-black uppercase tracking-widest ${paymentMethod === 'card' ? 'text-primary' : 'text-slate-400'}`}>Local Card</span>
              {paymentMethod === 'card' && <div className="absolute top-3 right-3 text-primary"><Check className="w-4 h-4" /></div>}
            </button>
          </div>

          <Card className="overflow-hidden border-none shadow-2xl shadow-slate-200/50 rounded-[2.5rem] bg-white">
             {paymentMethod === 'card' ? (
                <div className="p-12 space-y-10">
                   <div className="flex justify-between items-center pb-8 border-b border-slate-100">
                      <div>
                        <h4 className="font-brand font-bold text-2xl text-primary">Unified Card Gateway</h4>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Visa, Mastercard, & NexusPay Supported</p>
                      </div>
                      <div className="flex gap-4">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" className="h-5 opacity-40" alt="Visa" />
                        <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" className="h-5 opacity-40" alt="Mastercard" />
                      </div>
                   </div>
                   <div className="space-y-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Cardholder Name</label>
                        <Input required className="h-14 border-slate-100 bg-slate-50/50 rounded-2xl" placeholder="EVELYN V." />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Card Number</label>
                        <div className="relative">
                          <Input required className="h-14 border-slate-100 bg-slate-50/50 rounded-2xl font-mono tracking-widest" placeholder="4242 4242 4242 4242" maxLength={19} />
                          <CreditCard className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-300 w-5 h-5" />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-6">
                        <div className="space-y-2">
                           <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Expiry Date</label>
                           <Input required className="h-14 border-slate-100 bg-slate-50/50 rounded-2xl" placeholder="MM / YY" />
                        </div>
                        <div className="space-y-2">
                           <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">CVV/CVC</label>
                           <Input required type="password" className="h-14 border-slate-100 bg-slate-50/50 rounded-2xl" placeholder="•••" maxLength={3} />
                        </div>
                      </div>
                   </div>
                   <Button onClick={handleFinalizeOrder} disabled={isProcessing} className="w-full h-16 bg-primary text-white text-[10px] font-black uppercase tracking-[0.4em]">
                      {isProcessing ? <Loader2 className="w-6 h-6 animate-spin" /> : `Finalize ৳${total.toLocaleString()}`}
                   </Button>
                </div>
             ) : (
                <div className="flex flex-col">
                   <div className="p-12 text-center text-white" style={{ backgroundColor: getBrandColor() }}>
                      <p className="text-[10px] font-black uppercase tracking-[0.5em] mb-4 opacity-60">Bahari Secure Checkout</p>
                      <h4 className="font-brand font-bold text-4xl mb-2">{paymentMethod.charAt(0).toUpperCase() + paymentMethod.slice(1)} Pay</h4>
                      <p className="text-sm font-light opacity-80">Payable amount: <span className="font-bold">৳{total.toLocaleString()}</span></p>
                   </div>
                   <div className="p-12 bg-white">
                      <form onSubmit={handleMfsFlow} className="space-y-10">
                        {mfsStep === 'number' && (
                          <div className="space-y-6 animate-in slide-in-from-bottom-4">
                             <div className="text-center space-y-2">
                                <label className="text-sm font-bold text-slate-900">Your {paymentMethod} Account Number</label>
                                <p className="text-xs text-slate-400 italic font-light">Enter the 11-digit mobile number associated with your wallet.</p>
                             </div>
                             <Input 
                                required 
                                className="h-16 text-center text-2xl font-black tracking-[0.3em] border-slate-100 bg-slate-50/50 rounded-3xl focus:ring-accent" 
                                placeholder="01XXXXXXXXX" 
                                value={mfsNumber}
                                onChange={e => setMfsNumber(e.target.value)}
                                maxLength={11}
                             />
                          </div>
                        )}
                        {mfsStep === 'otp' && (
                          <div className="space-y-6 animate-in slide-in-from-bottom-4">
                             <div className="text-center space-y-2">
                                <label className="text-sm font-bold text-slate-900">One-Time Password (OTP)</label>
                                <p className="text-xs text-slate-400 italic font-light">We've sent a 6-digit code to your mobile device.</p>
                             </div>
                             <Input 
                                required 
                                className="h-16 text-center text-2xl font-black tracking-[0.5em] border-slate-100 bg-slate-50/50 rounded-3xl focus:ring-accent" 
                                placeholder="••••••" 
                                value={otp}
                                onChange={e => setOtp(e.target.value)}
                                maxLength={6}
                             />
                             <button type="button" className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mx-auto hover:text-primary">Resend Code in 42s</button>
                          </div>
                        )}
                        {mfsStep === 'pin' && (
                          <div className="space-y-6 animate-in slide-in-from-bottom-4">
                             <div className="text-center space-y-2">
                                <label className="text-sm font-bold text-slate-900">Secure PIN</label>
                                <p className="text-xs text-slate-400 italic font-light">Enter your confidential {paymentMethod} PIN to authorize.</p>
                             </div>
                             <div className="relative max-w-[200px] mx-auto">
                               <Input 
                                  required 
                                  type="password"
                                  className="h-16 text-center text-2xl font-black tracking-[0.8em] border-slate-100 bg-slate-50/50 rounded-3xl focus:ring-accent" 
                                  placeholder="•••••" 
                                  value={pin}
                                  onChange={e => setPin(e.target.value)}
                                  maxLength={5}
                               />
                               <Fingerprint className="absolute -right-12 top-1/2 -translate-y-1/2 text-slate-200 w-8 h-8" />
                             </div>
                          </div>
                        )}

                        <div className="space-y-4">
                          <Button 
                            type="submit" 
                            disabled={isProcessing} 
                            style={{ backgroundColor: getBrandColor() }}
                            className="w-full h-16 text-white text-[10px] font-black uppercase tracking-[0.4em] shadow-xl transition-all hover:brightness-110"
                          >
                             {isProcessing ? <Loader2 className="w-6 h-6 animate-spin" /> : (mfsStep === 'pin' ? 'Confirm Transaction' : 'Proceed')}
                          </Button>
                          <div className="flex items-center justify-center gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                             <ShieldCheck className="w-4 h-4 text-green-500" />
                             <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">Merchant: Bahari Box (TLS 1.3 Encryption)</p>
                          </div>
                        </div>
                      </form>
                   </div>
                </div>
             )}
          </Card>
          
          <button onClick={() => setStep(1)} className="block mx-auto text-[10px] font-black uppercase tracking-widest text-slate-300 hover:text-primary transition-colors flex items-center gap-2">
            <ArrowLeft className="w-4 h-4" /> Modify Delivery Details
          </button>
        </div>
      )}

      {step === 3 && (
        <div className="max-w-2xl mx-auto py-20 text-center animate-in fade-in zoom-in duration-700">
          <div className="w-28 h-28 bg-green-50 text-green-500 rounded-full flex items-center justify-center mx-auto mb-10 shadow-2xl shadow-green-100 border border-green-100">
            <CheckCircle className="w-16 h-16 stroke-[1.5]" />
          </div>
          <h2 className="font-brand text-6xl font-bold text-primary mb-6 italic">Treasures Await.</h2>
          <p className="text-slate-500 text-lg font-light leading-relaxed mb-12 italic">
            Your payment of <span className="font-bold text-primary">৳{total.toLocaleString()}</span> via <span className="font-bold text-primary uppercase">{paymentMethod}</span> was processed successfully. 
            Prepare for an unboxing experience that redefines thoughtfulness.
          </p>
          
          <Card className="p-12 border-2 border-dashed border-slate-200 bg-white rounded-[3rem] space-y-10 mb-16">
            <div className="grid grid-cols-2 gap-8 text-left">
               <div>
                  <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Curation ID</h5>
                  <p className="font-brand font-bold text-xl text-primary">{orderId}</p>
               </div>
               <div>
                  <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Gateway Auth</h5>
                  <p className="font-mono text-sm font-bold text-primary tracking-widest">{txId}</p>
               </div>
               <div className="col-span-2 pt-6 border-t border-slate-100">
                  <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Estimated Arrival</h5>
                  <p className="text-sm font-light text-slate-500 italic">Expected at your doorstep in Dhaka within 48 to 72 hours.</p>
               </div>
            </div>
            <div className="bg-slate-50 p-6 rounded-2xl flex items-center gap-4 text-left">
               <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-primary shadow-sm flex-shrink-0">
                  <Info className="w-5 h-5" />
               </div>
               <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider leading-relaxed">
                  A digital certificate and VAT invoice have been dispatched to <span className="text-primary">{shippingInfo.email}</span>.
               </p>
            </div>
          </Card>

          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Link to="/">
              <Button variant="outline" className="px-12 h-16 border-slate-200 text-[10px] font-black uppercase tracking-widest hover:border-primary transition-all rounded-none">Return Home</Button>
            </Link>
            <Link to="/account">
              <Button className="px-12 h-16 bg-primary text-white text-[10px] font-black uppercase tracking-widest shadow-2xl shadow-primary/20 rounded-none">Track My Box</Button>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
};

export default Checkout;
