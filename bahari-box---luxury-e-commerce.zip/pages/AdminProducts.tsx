
import React, { useState } from 'react';
import { useStore } from '../store';
import { Button, Input, Textarea, Card, Badge, Modal } from '../components/UI';
import { CATEGORIES } from '../constants';
import { 
  Search, Plus, Edit, Trash2, Sparkles, 
  Loader2, Filter, ChevronDown, MoreHorizontal,
  LayoutGrid, List, CheckSquare, Package
} from 'lucide-react';
import { generateProductDescription } from '../geminiService';
import { Product } from '../types';

const AdminProducts: React.FC = () => {
  const { products, addProduct, updateProduct, deleteProduct } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    description: '',
    price: 0,
    category: CATEGORIES[0],
    stock: 0,
    image: 'https://picsum.photos/600/600',
    features: ''
  });

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         p.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleOpenAdd = () => {
    setIsEditing(false);
    setFormData({ id: '', name: '', description: '', price: 0, category: CATEGORIES[0], stock: 0, image: 'https://picsum.photos/600/600', features: '' });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (product: Product) => {
    setIsEditing(true);
    setFormData({ ...product, features: '' });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isEditing) {
      updateProduct(formData as any);
    } else {
      addProduct(formData as any);
    }
    setIsModalOpen(false);
  };

  const handleAiGenerate = async () => {
    if (!formData.name) return alert("Please enter a product name first");
    setIsAiLoading(true);
    const desc = await generateProductDescription(formData.name, formData.features);
    setFormData(prev => ({ ...prev, description: desc }));
    setIsAiLoading(false);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h1 className="text-2xl font-brand font-bold text-slate-900">Inventory Management</h1>
          <div className="flex items-center gap-2 mt-1 text-xs font-medium text-slate-500">
             <span>Admin</span>
             <ChevronDown className="w-3 h-3" />
             <span className="text-primary font-bold">Catalog</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
           <div className="flex bg-slate-100 p-1 rounded-xl">
              <button onClick={() => setViewMode('list')} className={`p-1.5 rounded-lg transition-all ${viewMode === 'list' ? 'bg-white shadow-sm text-primary' : 'text-slate-400 hover:text-slate-600'}`}><List className="w-4 h-4" /></button>
              <button onClick={() => setViewMode('grid')} className={`p-1.5 rounded-lg transition-all ${viewMode === 'grid' ? 'bg-white shadow-sm text-primary' : 'text-slate-400 hover:text-slate-600'}`}><LayoutGrid className="w-4 h-4" /></button>
           </div>
           <Button onClick={handleOpenAdd} className="h-10 px-6 rounded-xl shadow-lg shadow-primary/20">
             <Plus className="w-4 h-4" /> Add New Product
           </Button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row justify-between items-center gap-4">
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto">
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <input 
              placeholder="Search catalog by name, ID or description..." 
              className="w-full pl-9 h-11 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent" 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="relative w-full sm:w-48">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4 pointer-events-none" />
            <select 
              className="w-full h-11 pl-9 pr-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent text-sm appearance-none bg-white"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="All">All Collections</option>
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>
        <div className="flex gap-2 w-full lg:w-auto">
           <Button variant="outline" className="h-11 bg-white border-slate-200 text-xs font-bold rounded-xl px-4 flex-grow lg:flex-initial">
             <CheckSquare className="w-3.5 h-3.5" /> Bulk Edit
           </Button>
        </div>
      </div>

      {viewMode === 'list' ? (
        <Card className="border-slate-200 rounded-2xl shadow-sm bg-white overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/30">
                  <th className="px-6 py-4 w-10">
                    <input type="checkbox" className="rounded border-slate-300 text-primary focus:ring-primary h-4 w-4" />
                  </th>
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Product Info</th>
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Category</th>
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Pricing</th>
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400">Inventory Status</th>
                  <th className="px-6 py-4 text-[10px] font-black uppercase tracking-widest text-slate-400 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filteredProducts.length > 0 ? (
                  filteredProducts.map((product) => (
                    <tr key={product.id} className="hover:bg-slate-50 transition-colors group">
                      <td className="px-6 py-4">
                        <input type="checkbox" className="rounded border-slate-300 text-primary focus:ring-primary h-4 w-4" />
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-xl overflow-hidden bg-slate-100 border border-slate-200 group-hover:scale-110 transition-transform">
                            <img src={product.image} className="w-full h-full object-cover" alt="" />
                          </div>
                          <div className="min-w-0">
                            <p className="font-bold text-slate-900 text-sm leading-tight mb-0.5 truncate max-w-[180px]">{product.name}</p>
                            <p className="text-[10px] text-slate-400 font-mono font-bold tracking-tight">ID: {product.id}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <Badge variant="info">{product.category}</Badge>
                      </td>
                      <td className="px-6 py-4 font-black text-slate-900 text-sm">৳{product.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                      <td className="px-6 py-4">
                        <div className="flex flex-col">
                          <span className={`font-bold text-xs ${product.stock < 10 ? 'text-red-600' : 'text-slate-600'}`}>
                            {product.stock} units
                          </span>
                          <div className="w-24 h-1.5 bg-slate-100 rounded-full mt-1.5 overflow-hidden">
                             <div 
                               className={`h-full rounded-full ${product.stock < 10 ? 'bg-red-500' : 'bg-primary'}`} 
                               style={{ width: `${Math.min(100, (product.stock / 50) * 100)}%` }}
                             ></div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button onClick={() => handleOpenEdit(product)} className="p-2 text-slate-400 hover:text-primary hover:bg-white hover:shadow-sm rounded-lg transition-all" title="Edit">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button onClick={() => { if(confirm('Delete this product?')) deleteProduct(product.id) }} className="p-2 text-slate-400 hover:text-red-500 hover:bg-white hover:shadow-sm rounded-lg transition-all" title="Delete">
                            <Trash2 className="w-4 h-4" />
                          </button>
                          <button className="p-2 text-slate-400 hover:text-slate-900 rounded-lg transition-all">
                            <MoreHorizontal className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="px-6 py-20 text-center">
                      <div className="flex flex-col items-center gap-4 grayscale opacity-40">
                        <Package className="w-16 h-16" />
                        <div className="space-y-1">
                          <h3 className="text-lg font-bold text-slate-900">No items found</h3>
                          <p className="text-sm text-slate-500">Try adjusting your filters or search terms.</p>
                        </div>
                        <Button variant="ghost" onClick={() => { setSearchTerm(''); setSelectedCategory('All'); }} className="text-xs bg-slate-50">Clear All Filters</Button>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map(product => (
            <Card key={product.id} className="group hover:shadow-xl transition-all border-slate-200">
              <div className="aspect-square relative overflow-hidden bg-slate-50 p-2">
                <img src={product.image} className="w-full h-full object-cover rounded-xl group-hover:scale-105 transition-transform duration-500" alt="" />
                <div className="absolute top-4 right-4 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0">
                  <button onClick={() => handleOpenEdit(product)} className="p-2 bg-white rounded-lg shadow-lg text-primary hover:bg-primary hover:text-white transition-all"><Edit className="w-4 h-4" /></button>
                  <button onClick={() => deleteProduct(product.id)} className="p-2 bg-white rounded-lg shadow-lg text-red-500 hover:bg-red-500 hover:text-white transition-all"><Trash2 className="w-4 h-4" /></button>
                </div>
                <div className="absolute bottom-4 left-4">
                  <Badge variant={product.stock < 10 ? 'error' : 'success'}>
                    {product.stock < 10 ? 'Low Stock' : 'In Stock'}
                  </Badge>
                </div>
              </div>
              <div className="p-5">
                <p className="text-[10px] font-black uppercase text-secondary tracking-widest mb-1">{product.category}</p>
                <h3 className="font-bold text-slate-900 truncate mb-1">{product.name}</h3>
                <p className="text-sm font-black text-primary">৳{product.price.toLocaleString()}</p>
                <div className="mt-4 pt-4 border-t border-slate-100 flex justify-between items-center">
                   <span className="text-xs text-slate-400 font-bold">{product.stock} units left</span>
                   <button onClick={() => handleOpenEdit(product)} className="text-xs font-bold text-primary hover:underline">Manage</button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={isEditing ? "Modify Catalog Item" : "Create New Inventory Item"}>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div className="col-span-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 block">Display Name</label>
              <Input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="e.g. Midnight Bloom artisanal Box" className="h-11 rounded-xl" />
            </div>
            <div>
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 block">Unit Price (৳)</label>
              <Input required type="number" step="0.01" value={formData.price} onChange={e => setFormData({...formData, price: parseFloat(e.target.value)})} className="h-11 rounded-xl" />
            </div>
            <div>
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 block">Collection</label>
              <select 
                className="w-full h-11 px-4 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-accent text-sm appearance-none bg-white"
                value={formData.category} 
                onChange={e => setFormData({...formData, category: e.target.value})}
              >
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 block">Opening Stock</label>
              <Input required type="number" value={formData.stock} onChange={e => setFormData({...formData, stock: parseInt(e.target.value)})} className="h-11 rounded-xl" />
            </div>
            <div>
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 block">Hero Image URL</label>
              <Input required value={formData.image} onChange={e => setFormData({...formData, image: e.target.value})} className="h-11 rounded-xl" />
            </div>
          </div>

          <div className="p-5 bg-purple-50 rounded-2xl border border-purple-100 space-y-4">
             <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center shadow-sm">
                    <Sparkles className="w-4 h-4 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-purple-900 uppercase tracking-widest">AI Copywriter</h4>
                    <p className="text-[10px] text-purple-600 font-medium">Generate SEO-ready descriptions</p>
                  </div>
                </div>
                <Button 
                  type="button" 
                  variant="ghost" 
                  className="text-xs text-white bg-purple-600 h-9 px-4 rounded-xl hover:bg-purple-700 shadow-md shadow-purple-200" 
                  onClick={handleAiGenerate}
                  disabled={isAiLoading}
                >
                  {isAiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Write for Me"}
                </Button>
             </div>
             <Input 
                placeholder="List 2-3 unique selling points (e.g. hand-poured, limited release)" 
                value={formData.features}
                onChange={e => setFormData({...formData, features: e.target.value})}
                className="text-sm bg-white border-purple-200 focus:ring-purple-200 rounded-xl h-10"
             />
          </div>

          <div>
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2 block">Product Narrative</label>
            <Textarea 
              required 
              placeholder="The story behind this piece..."
              value={formData.description} 
              onChange={e => setFormData({...formData, description: e.target.value})} 
              className="rounded-2xl min-h-[120px] bg-slate-50 border-slate-200 focus:bg-white transition-all"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <Button type="button" variant="outline" onClick={() => setIsModalOpen(false)} className="px-8 rounded-xl h-11 border-slate-200 font-bold">Discard</Button>
            <Button type="submit" className="px-10 rounded-xl h-11 font-bold shadow-xl shadow-primary/20">{isEditing ? "Update Item" : "Publish to Store"}</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default AdminProducts;
