
import React, { useState, useEffect } from 'react';
import { useStore } from '../store';
import { Card, Button } from '../components/UI';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingBag, ArrowRight, Star, Heart, Check, Play, Quote, ChevronRight, Eye } from 'lucide-react';
import { Logo } from '../components/Layout';
import { Product } from '../types';

export const ProductCard: React.FC<{ product: Product; priority?: boolean }> = ({ product, priority }) => {
  const { addToCart } = useStore();
  const navigate = useNavigate();
  const [isAdded, setIsAdded] = useState(false);

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
    setIsAdded(true);
  };

  useEffect(() => {
    if (isAdded) {
      const timer = setTimeout(() => setIsAdded(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [isAdded]);

  return (
    <div 
      className={`group cursor-pointer ${priority ? 'lg:col-span-2 lg:row-span-2' : ''}`}
      onClick={() => navigate(`/product/${product.id}`)}
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-[#F5F5F5] transition-all duration-700">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-[2s] ease-out group-hover:scale-105"
        />
        {product.featured && (
          <div className="absolute top-6 left-6">
             <span className="bg-white/90 backdrop-blur-md px-4 py-1.5 text-[8px] font-black uppercase tracking-[0.3em] text-primary shadow-sm">Featured</span>
          </div>
        )}
        <div className="absolute inset-0 bg-primary/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col items-center justify-center p-8 gap-4">
           <Button 
             variant="primary" 
             className={`w-full py-5 text-[10px] font-black uppercase tracking-[0.2em] shadow-2xl transition-all duration-700 transform ${isAdded ? 'bg-green-600 border-green-600' : 'translate-y-4 group-hover:translate-y-0 bg-primary border-none'}`} 
             onClick={handleAdd}
           >
             {isAdded ? (
               <><div className="flex items-center gap-2"><Check className="w-4 h-4" /> Added</div></>
             ) : (
               <><div className="flex items-center gap-2"><ShoppingBag className="w-4 h-4" /> Add to Box</div></>
             )}
           </Button>
           <button className="flex items-center gap-2 text-[8px] font-black uppercase tracking-[0.3em] text-white opacity-0 group-hover:opacity-100 translate-y-8 group-hover:translate-y-0 transition-all duration-700 delay-100">
             <Eye className="w-3.5 h-3.5" /> Quick Detail
           </button>
        </div>
      </div>
      <div className="pt-8 space-y-2">
        <p className="text-[9px] text-accent uppercase tracking-[0.3em] font-black">{product.category}</p>
        <div className="flex justify-between items-baseline gap-4">
          <h3 className="text-base font-brand font-bold text-primary group-hover:text-accent transition-colors leading-tight">{product.name}</h3>
          <span className="text-sm font-light text-slate-400">৳{product.price.toLocaleString()}</span>
        </div>
      </div>
    </div>
  );
};

const Home: React.FC = () => {
  const { products } = useStore();
  const featured = products.slice(0, 5);

  return (
    <div className="pb-0 overflow-x-hidden">
      {/* Editorial Hero */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden bg-[#F1EFEC]">
        <div className="absolute inset-0 z-0">
           <img 
             src="https://images.unsplash.com/photo-1513201099705-a9746e1e201f?auto=format&fit=crop&q=80&w=2000" 
             className="w-full h-full object-cover opacity-80 animate-in fade-in zoom-in-105 duration-[3s]"
             alt="Hero"
           />
           <div className="absolute inset-0 bg-gradient-to-b from-primary/10 via-transparent to-primary/30"></div>
        </div>

        <div className="relative z-10 text-center px-6 max-w-4xl">
          <span className="inline-block text-[10px] font-black uppercase tracking-[0.6em] text-white/80 mb-8 animate-in fade-in slide-in-from-top-4 duration-1000">The Holiday Collection 2024</span>
          <h1 className="font-brand text-6xl sm:text-9xl font-bold mb-12 leading-[0.9] text-white drop-shadow-2xl animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-200">
            Unwrap <br/>
            <span className="italic font-normal bg-white text-primary px-8 py-2 mt-4 inline-block shadow-2xl">
              Thoughtfulness.
            </span>
          </h1>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 animate-in fade-in duration-1000 delay-500">
            <Link to="/products">
              <Button className="px-12 py-7 text-[10px] font-black uppercase tracking-[0.3em] bg-white text-primary border-none hover:bg-accent hover:text-white transition-all shadow-2xl rounded-none">
                <div className="flex items-center gap-2">Explore The Catalog <ArrowRight className="w-4 h-4" /></div>
              </Button>
            </Link>
          </div>
        </div>

        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4 text-white/50">
           <span className="text-[9px] font-black uppercase tracking-widest">Scroll</span>
           <div className="w-[1px] h-16 bg-gradient-to-b from-white/50 to-transparent"></div>
        </div>
      </section>

      {/* Brand Ethos - Split Minimalist */}
      <section className="py-40 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-32 items-center">
              <div className="relative">
                 <div className="aspect-[4/5] overflow-hidden">
                    <img 
                      src="https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&q=80&w=1200" 
                      className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000"
                      alt="Artisanal Packaging"
                    />
                 </div>
                 <div className="absolute -bottom-12 -right-12 w-64 h-80 bg-[#F1EFEC] -z-10 hidden lg:block"></div>
                 <div className="absolute -top-12 -left-12 p-8 bg-white shadow-xl hidden lg:block">
                    <p className="font-brand italic text-2xl text-primary">"The box is as important <br/> as the gift inside."</p>
                 </div>
              </div>
              <div className="space-y-12">
                 <div className="space-y-6">
                    <h2 className="font-brand text-5xl lg:text-7xl font-bold text-primary leading-tight">The Bahari <br/>Standard.</h2>
                    <p className="text-lg text-slate-500 font-light leading-relaxed max-w-md italic">
                      "We don't just ship boxes; we deliver emotions. Every item is hand-vetted for its story, quality, and aesthetic soul."
                    </p>
                 </div>
                 <div className="space-y-10">
                    {[
                      { title: 'Sourcing', desc: 'Directly from independent global makers.' },
                      { title: 'Curation', desc: 'Themes built around human connection.' },
                      { title: 'Finish', desc: 'Sustainable, bespoke, and scented packaging.' }
                    ].map((step, i) => (
                      <div key={i} className="flex gap-8 group">
                         <span className="text-accent font-brand italic text-3xl opacity-30 group-hover:opacity-100 transition-opacity">0{i+1}</span>
                         <div>
                            <h4 className="text-xs font-black uppercase tracking-widest text-primary mb-1">{step.title}</h4>
                            <p className="text-sm text-slate-400 font-light">{step.desc}</p>
                         </div>
                      </div>
                    ))}
                 </div>
                 <Button variant="outline" className="px-0 border-none text-accent hover:bg-transparent hover:text-primary transition-all group">
                    <div className="flex items-center gap-2">Our Full Philosophy <ChevronRight className="w-4 h-4 group-hover:translate-x-2 transition-transform" /></div>
                 </Button>
              </div>
           </div>
        </div>
      </section>

      {/* Editorial Grid */}
      <section className="py-40 bg-[#FCFBFC]">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="flex flex-col md:flex-row justify-between items-baseline mb-24 gap-8">
            <div className="space-y-4">
               <span className="text-accent text-[10px] font-black uppercase tracking-[0.4em]">Selection 01</span>
               <h2 className="font-brand text-5xl font-bold text-primary italic">The Artisanal Choice</h2>
            </div>
            <Link to="/products" className="text-[10px] font-black uppercase tracking-[0.3em] text-primary border-b border-primary/20 pb-2 hover:border-accent transition-colors">Browse Entire Catalog</Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-32">
            {featured.map((p, i) => (
              <ProductCard key={p.id} product={p} priority={i === 0} />
            ))}
          </div>
        </div>
      </section>

      {/* Quote Section */}
      <section className="py-56 bg-primary text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
           <img src="https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&q=80&w=2000" className="w-full h-full object-cover" alt="" />
        </div>
        <div className="max-w-4xl mx-auto px-6 text-center relative z-10 space-y-16">
           <Quote className="w-16 h-16 mx-auto text-accent opacity-50" />
           <h2 className="font-brand text-4xl lg:text-6xl font-bold leading-tight italic">
             "I wanted something that felt like a hug in a box. Bahari didn't just meet my expectations, they redefined them."
           </h2>
           <div className="space-y-4">
              <div className="w-20 h-[1px] bg-accent mx-auto"></div>
              <p className="text-[10px] font-black uppercase tracking-[0.5em] text-accent">Elena V. — London</p>
           </div>
        </div>
      </section>

      {/* Luxury Newsletter */}
      <section className="py-40 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
           <div className="bg-[#F1EFEC] p-16 lg:p-32 flex flex-col items-center text-center">
              <span className="text-accent text-[10px] font-black uppercase tracking-[0.5em] mb-12">Stay Inspired</span>
              <h2 className="font-brand text-5xl lg:text-7xl font-bold text-primary mb-8 max-w-2xl">A Journal of Thoughtful Living.</h2>
              <p className="text-slate-500 text-lg font-light mb-16 max-w-md leading-relaxed italic">
                Join our circle for exclusive seasonal releases, artisanal deep-dives, and early access to the 2024 Collection.
              </p>
              <div className="w-full max-w-xl flex flex-col sm:flex-row gap-0 group">
                 <input 
                   type="email" 
                   placeholder="Your email address" 
                   className="flex-grow bg-white border-none px-8 py-6 text-primary focus:ring-1 focus:ring-accent transition-all text-sm uppercase tracking-widest placeholder:text-slate-300"
                 />
                 <Button className="bg-primary text-white rounded-none px-12 py-6 text-[10px] font-black uppercase tracking-[0.3em] hover:bg-accent transition-colors">Join</Button>
              </div>
              <p className="mt-8 text-[9px] text-slate-400 font-bold uppercase tracking-widest">No Spam. Just inspiration. Always curated.</p>
           </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
