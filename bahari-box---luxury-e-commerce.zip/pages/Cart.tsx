
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';
import { Button, Card, Badge } from '../components/UI';
import { Trash2, Minus, Plus, ShoppingCart, ArrowRight } from 'lucide-react';

const Cart: React.FC = () => {
  const { cart, updateCartQuantity, removeFromCart } = useStore();
  const [removingId, setRemovingId] = useState<string | null>(null);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const shipping = subtotal > 1500 ? 0 : 150;
  const total = subtotal + shipping;

  const handleRemove = (id: string) => {
    setRemovingId(id);
    // Wait for animation to finish before removing from store
    setTimeout(() => {
      removeFromCart(id);
      setRemovingId(null);
    }, 300);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    updateCartQuantity(id, delta);
    setUpdatingId(id);
    // Reset updating ID after animation duration to allow re-triggering
    setTimeout(() => setUpdatingId(null), 200);
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center animate-in fade-in zoom-in duration-500">
        <div className="bg-slate-50 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
          <ShoppingCart className="w-10 h-10 text-slate-300" />
        </div>
        <h2 className="text-3xl font-bold text-slate-900 mb-4">Your cart is empty</h2>
        <p className="text-slate-500 mb-8 max-w-md mx-auto">Looks like you haven't added anything to your cart yet. Browse our products and find something you like!</p>
        <Link to="/products">
          <Button variant="primary">Start Shopping</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 animate-in fade-in duration-500">
      <h1 className="text-3xl font-bold text-slate-900 mb-8">Shopping Cart</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-6">
          {cart.map((item) => (
            <div 
              key={item.id} 
              className={`transition-all duration-300 ease-out transform ${
                removingId === item.id ? 'opacity-0 -translate-x-12 scale-95 pointer-events-none' : 'opacity-100'
              }`}
            >
              <Card className="p-4 flex gap-6 hover:shadow-md transition-shadow">
                <div className="w-24 h-24 bg-slate-100 rounded-lg overflow-hidden flex-shrink-0">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-grow">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-slate-900">{item.name}</h3>
                    <button 
                      onClick={() => handleRemove(item.id)} 
                      className="text-slate-400 hover:text-red-500 transition-colors p-1"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                  <p className="text-sm text-slate-500 mb-4">{item.category}</p>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-3 bg-slate-50 rounded-lg p-1 border border-slate-100">
                      <button 
                        onClick={() => handleUpdateQuantity(item.id, -1)}
                        className="w-8 h-8 flex items-center justify-center text-slate-500 hover:bg-white hover:shadow-sm rounded-md transition-all active:scale-90"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className={`font-bold text-slate-900 w-6 text-center transition-transform ${updatingId === item.id ? 'animate-pop' : ''}`}>
                        {item.quantity}
                      </span>
                      <button 
                        onClick={() => handleUpdateQuantity(item.id, 1)}
                        className="w-8 h-8 flex items-center justify-center text-slate-500 hover:bg-white hover:shadow-sm rounded-md transition-all active:scale-90"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="font-bold text-slate-900">৳{(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                </div>
              </Card>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <Card className="p-6 sticky top-24 shadow-lg border-primary/5">
            <h2 className="text-xl font-bold text-slate-900 mb-6">Order Summary</h2>
            <div className="space-y-4 mb-6">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-medium text-slate-900">৳{subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Shipping</span>
                <span className="font-medium text-slate-900">
                  {shipping === 0 ? <Badge variant="success">Free</Badge> : `৳${shipping.toFixed(2)}`}
                </span>
              </div>
              {shipping > 0 && (
                <p className="text-xs text-slate-400 italic">Add ৳{(1500 - subtotal).toFixed(2)} more for free shipping!</p>
              )}
              <div className="pt-4 border-t border-slate-100 flex justify-between items-center">
                <span className="text-lg font-bold text-slate-900">Total</span>
                <span className="text-xl font-bold text-primary">৳{total.toFixed(2)}</span>
              </div>
            </div>
            <Link to="/checkout">
              <Button variant="secondary" className="w-full py-4 text-lg hover:scale-[1.02] transition-transform active:scale-98">
                Checkout Now <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <div className="mt-4 flex items-center justify-center gap-2 text-xs text-slate-400 uppercase tracking-widest font-bold">
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
              Secure Transaction
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Cart;