
import React from 'react';
import { Navigate, Link } from 'react-router-dom';
import { useStore } from '../store';
import { Card, Badge, Button } from '../components/UI';
import { 
  Box, Heart, Settings, Clock, 
  ChevronRight, MapPin, CreditCard, 
  Gift, ShoppingBag, Star
} from 'lucide-react';

const CustomerDashboard: React.FC = () => {
  const { customer, isCustomerAuthenticated, orders } = useStore();

  if (!isCustomerAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Filter orders for this mock customer (based on email)
  const myOrders = orders.filter(o => o.customerEmail === customer?.email);

  return (
    <div className="max-w-7xl mx-auto px-6 lg:px-12 py-16">
      {/* Header Profile */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-8 mb-20">
         <div className="space-y-4">
            <span className="text-accent text-[10px] font-black uppercase tracking-[0.5em]">The Circle Member</span>
            <h1 className="font-brand text-5xl font-bold text-primary italic">Welcome back, {customer?.name.split(' ')[0]}.</h1>
            <p className="text-slate-500 font-light flex items-center gap-2">
              <Star className="w-4 h-4 text-accent fill-current" /> Part of the Bahari Family since {new Date(customer!.joinedDate).toLocaleDateString()}
            </p>
         </div>
         <div className="flex gap-4">
            <Button variant="outline" className="border-slate-200 h-12 px-6 text-[10px] font-black uppercase tracking-widest">
               Edit Profile
            </Button>
            <Link to="/products">
              <Button className="h-12 px-8 bg-primary text-white text-[10px] font-black uppercase tracking-widest shadow-xl shadow-primary/10">
                 Shop New Arrivals
              </Button>
            </Link>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-12">
          {/* Recent Orders */}
          <section className="space-y-6">
            <h3 className="text-xs font-black uppercase tracking-[0.4em] text-primary pb-4 border-b border-slate-100 flex justify-between items-center">
               Your Collections 
               <span className="text-slate-300 font-bold">{myOrders.length} total</span>
            </h3>
            {myOrders.length > 0 ? (
               <div className="space-y-4">
                 {myOrders.map(order => (
                   <Card key={order.id} className="p-8 border-none shadow-[0_10px_40px_-15px_rgba(0,0,0,0.05)] hover:shadow-[0_20px_60px_-15px_rgba(0,0,0,0.1)] transition-all group">
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
                         <div className="flex items-center gap-6">
                            <div className="w-16 h-16 rounded-2xl bg-slate-50 flex items-center justify-center text-primary group-hover:bg-accent group-hover:text-white transition-all">
                               <Box className="w-8 h-8" />
                            </div>
                            <div>
                               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{order.date}</p>
                               <h4 className="font-brand font-bold text-xl text-primary">{order.id}</h4>
                               <p className="text-sm text-slate-500 font-light">৳{order.total.toLocaleString()}</p>
                            </div>
                         </div>
                         <div className="flex items-center gap-6 w-full sm:w-auto">
                            <Badge variant={order.status === 'Delivered' ? 'success' : 'info'} className="h-8 px-4 flex items-center justify-center font-black uppercase tracking-widest">
                               {order.status}
                            </Badge>
                            <button className="p-2 text-slate-300 hover:text-primary transition-colors">
                               <ChevronRight className="w-6 h-6" />
                            </button>
                         </div>
                      </div>
                   </Card>
                 ))}
               </div>
            ) : (
              <div className="py-20 text-center bg-slate-50/50 rounded-[2rem] border-2 border-dashed border-slate-100">
                 <ShoppingBag className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                 <p className="text-slate-400 font-light italic text-lg mb-8">No collections curated yet.</p>
                 <Link to="/products" className="text-[10px] font-black text-primary underline underline-offset-8 tracking-widest uppercase">Start Curating</Link>
              </div>
            )}
          </section>

          {/* Style Profile Mock */}
          <section className="space-y-6">
             <h3 className="text-xs font-black uppercase tracking-[0.4em] text-primary pb-4 border-b border-slate-100">Style Preferences</h3>
             <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <Card className="p-8 bg-primary text-white rounded-[2rem] overflow-hidden relative">
                   <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -translate-y-8 translate-x-8"></div>
                   <p className="text-[9px] font-black uppercase tracking-[0.4em] text-white/40 mb-2">Primary Interest</p>
                   <h4 className="font-brand text-3xl font-bold mb-6 italic text-accent">Artisanal Living</h4>
                   <p className="text-xs text-white/50 leading-relaxed font-light">Your history shows a 78% preference for hand-crafted ceramics and wellness sets.</p>
                </Card>
                <div className="p-8 border-2 border-dashed border-slate-100 rounded-[2rem] flex flex-col items-center justify-center text-center">
                   <Gift className="w-8 h-8 text-accent mb-4" />
                   <h4 className="font-bold text-primary mb-2">Birthday Surprise</h4>
                   <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Available in 12 days</p>
                </div>
             </div>
          </section>
        </div>

        {/* Sidebar Info */}
        <aside className="space-y-8">
           <Card className="p-10 border-none shadow-xl shadow-slate-200/50 rounded-[2.5rem] bg-white space-y-10">
              <div className="space-y-6">
                 <div className="flex items-center gap-4 text-primary">
                    <MapPin className="w-5 h-5 text-accent" />
                    <div>
                       <h5 className="text-[10px] font-black uppercase tracking-widest">Primary Address</h5>
                       <p className="text-sm font-light text-slate-500">Not set yet</p>
                    </div>
                 </div>
                 <div className="flex items-center gap-4 text-primary">
                    <CreditCard className="w-5 h-5 text-accent" />
                    <div>
                       <h5 className="text-[10px] font-black uppercase tracking-widest">Stored Payment</h5>
                       <p className="text-sm font-light text-slate-500">•••• •••• •••• 4242</p>
                    </div>
                 </div>
                 <div className="flex items-center gap-4 text-primary">
                    <Clock className="w-5 h-5 text-accent" />
                    <div>
                       <h5 className="text-[10px] font-black uppercase tracking-widest">Last Browsed</h5>
                       <p className="text-sm font-light text-slate-500">The Midnight Bloom Set</p>
                    </div>
                 </div>
              </div>
              <Button variant="outline" className="w-full border-slate-100 py-4 h-auto text-[9px] font-black uppercase tracking-widest rounded-xl">
                 Update Preferences
              </Button>
           </Card>

           <div className="bg-[#F1EFEC] p-10 rounded-[2.5rem] space-y-6">
              <h4 className="font-brand font-bold text-xl text-primary">Circle Concierge</h4>
              <p className="text-sm text-slate-500 leading-relaxed font-light">
                Need bespoke curation for an event? Our team is available for one-on-one consultation.
              </p>
              <button className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-primary hover:text-accent transition-colors">
                Start Conversation <ChevronRight className="w-4 h-4" />
              </button>
           </div>
        </aside>
      </div>
    </div>
  );
};

export default CustomerDashboard;
