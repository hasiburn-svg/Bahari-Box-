
import React, { useState, useMemo } from 'react';
import { useStore } from '../store';
import { Card, Badge, Button, Input } from '../components/UI';
import { Search, Eye, ExternalLink, Trash2, ArrowUpDown, Filter, ChevronDown, ChevronUp, History, Download, CreditCard, Smartphone } from 'lucide-react';
import { OrderStatus, Order } from '../types';

type SortField = 'date' | 'total';
type SortOrder = 'asc' | 'desc';

const AdminOrders: React.FC = () => {
  const { orders, updateOrderStatus, clearOrders } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'All'>('All');
  const [sortConfig, setSortConfig] = useState<{ field: SortField; order: SortOrder }>({ field: 'date', order: 'desc' });

  const handleClearOrders = () => {
    if (window.confirm('Are you sure you want to clear the entire order history? This action cannot be undone.')) {
      clearOrders();
    }
  };

  const handleSort = (field: SortField) => {
    setSortConfig(prev => ({
      field,
      order: prev.field === field && prev.order === 'asc' ? 'desc' : 'asc'
    }));
  };

  const filteredAndSortedOrders = useMemo(() => {
    return orders
      .filter(order => {
        const matchesSearch = 
          order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
          order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          order.customerEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (order.transactionId && order.transactionId.toLowerCase().includes(searchTerm.toLowerCase()));
        
        const matchesStatus = statusFilter === 'All' || order.status === statusFilter;
        
        return matchesSearch && matchesStatus;
      })
      .sort((a, b) => {
        const field = sortConfig.field;
        const modifier = sortConfig.order === 'asc' ? 1 : -1;
        
        if (field === 'date') {
          return (new Date(a.date).getTime() - new Date(b.date).getTime()) * modifier;
        }
        if (field === 'total') {
          return (a.total - b.total) * modifier;
        }
        return 0;
      });
  }, [orders, searchTerm, statusFilter, sortConfig]);

  const exportToCSV = () => {
    if (filteredAndSortedOrders.length === 0) return;

    const headers = ['Order ID', 'Customer Name', 'Email', 'Date', 'Total (BDT)', 'Status', 'Gateway', 'TxID'];
    const rows = filteredAndSortedOrders.map(order => [
      order.id,
      `"${order.customerName.replace(/"/g, '""')}"`,
      order.customerEmail,
      order.date,
      order.total.toFixed(2),
      order.status,
      order.paymentMethod || 'N/A',
      order.transactionId || 'N/A'
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `bahari_orders_export_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const stats = useMemo(() => {
    return {
      pending: orders.filter(o => o.status === 'Pending').length,
      shipped: orders.filter(o => o.status === 'Shipped').length,
      delivered: orders.filter(o => o.status === 'Delivered').length,
    };
  }, [orders]);

  return (
    <div className="space-y-12">
      <div className="flex flex-col xl:flex-row xl:items-end justify-between gap-8">
        <div>
           <h1 className="text-4xl font-brand font-bold text-slate-900 italic">Logistics Management</h1>
           <p className="text-slate-500 font-medium">Monitoring artisanal flow and local transactional history.</p>
        </div>
        <div className="flex gap-4">
           <Button variant="outline" className="h-14 px-8 bg-white border-none shadow-sm text-xs font-black uppercase tracking-widest rounded-2xl" onClick={exportToCSV}>
             <Download className="w-4 h-4 mr-3" /> Export Ledger (CSV)
           </Button>
           <Button variant="danger" className="h-14 px-8 bg-red-50 text-red-600 border-none shadow-sm text-xs font-black uppercase tracking-widest rounded-2xl" onClick={handleClearOrders}>
             <Trash2 className="w-4 h-4 mr-3" /> Purge History
           </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
        <Card className="p-8 border-none bg-white shadow-xl shadow-slate-200/40">
           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 block">Awaiting Dispatch</span>
           <p className="text-4xl font-black text-primary">{stats.pending}</p>
        </Card>
        <Card className="p-8 border-none bg-white shadow-xl shadow-slate-200/40">
           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 block">Active Logistics</span>
           <p className="text-4xl font-black text-primary">{stats.shipped}</p>
        </Card>
        <Card className="p-8 border-none bg-white shadow-xl shadow-slate-200/40">
           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 block">Successfully Curated</span>
           <p className="text-4xl font-black text-primary">{stats.delivered}</p>
        </Card>
      </div>

      <Card className="border-none shadow-2xl shadow-slate-200/50 rounded-[2.5rem] bg-white overflow-hidden">
        <div className="p-10 border-b border-slate-50 flex flex-col md:flex-row justify-between items-center gap-6">
           <div className="relative flex-grow max-w-xl group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 w-5 h-5 group-focus-within:text-primary transition-colors" />
              <input 
                placeholder="Search TxID, Name or ID..." 
                className="w-full h-14 pl-12 pr-6 bg-slate-50 border-none rounded-2xl text-sm font-medium focus:ring-2 focus:ring-accent/10 focus:bg-white transition-all"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
           </div>
           <div className="flex items-center gap-4">
              <select 
                className="h-14 px-6 bg-slate-50 border-none rounded-2xl text-[10px] font-black uppercase tracking-widest outline-none focus:ring-2 focus:ring-accent/10"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
              >
                <option value="All">All Statuses</option>
                <option value="Pending">Pending</option>
                <option value="Shipped">Shipped</option>
                <option value="Delivered">Delivered</option>
                <option value="Cancelled">Cancelled</option>
              </select>
           </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="px-10 py-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Identification</th>
                <th className="px-10 py-6 text-[10px] font-black uppercase tracking-widest text-slate-400">The Curator</th>
                <th className="px-10 py-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Gateway Details</th>
                <th className="px-10 py-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Total BDT</th>
                <th className="px-10 py-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Curatorial Status</th>
                <th className="px-10 py-6 text-right text-[10px] font-black uppercase tracking-widest text-slate-400">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredAndSortedOrders.map((order) => (
                <tr key={order.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-10 py-8">
                    <p className="text-xs font-black text-slate-900 mb-1">{order.id}</p>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">{new Date(order.date).toLocaleDateString()}</p>
                  </td>
                  <td className="px-10 py-8">
                    <p className="text-sm font-bold text-primary mb-1">{order.customerName}</p>
                    <p className="text-[10px] text-slate-400 font-medium truncate max-w-[150px]">{order.customerEmail}</p>
                  </td>
                  <td className="px-10 py-8">
                    <div className="flex items-center gap-3 mb-1">
                      {order.paymentMethod === 'CARD' ? <CreditCard className="w-3.5 h-3.5 text-primary" /> : <Smartphone className="w-3.5 h-3.5 text-accent" />}
                      <span className="text-[10px] font-black uppercase tracking-widest text-primary">{order.paymentMethod || 'GUEST'}</span>
                    </div>
                    <p className="text-[9px] font-mono font-bold text-slate-400 tracking-widest">{order.transactionId || 'AWAITING AUTH'}</p>
                  </td>
                  <td className="px-10 py-8">
                    <span className="text-sm font-black text-slate-900">৳{order.total.toLocaleString()}</span>
                  </td>
                  <td className="px-10 py-8">
                    <select 
                      className={`text-[9px] font-black uppercase tracking-widest px-4 py-2 rounded-xl border border-transparent outline-none cursor-pointer transition-all ${
                        order.status === 'Delivered' ? 'bg-green-100 text-green-700' : 
                        order.status === 'Shipped' ? 'bg-blue-100 text-blue-700' :
                        order.status === 'Pending' ? 'bg-orange-100 text-orange-700' : 'bg-red-100 text-red-700'
                      }`}
                      value={order.status}
                      onChange={(e) => updateOrderStatus(order.id, e.target.value as OrderStatus)}
                    >
                      <option value="Pending">Pending</option>
                      <option value="Shipped">Shipped</option>
                      <option value="Delivered">Delivered</option>
                      <option value="Cancelled">Cancelled</option>
                    </select>
                  </td>
                  <td className="px-10 py-8 text-right">
                     <button className="p-3 bg-white border border-slate-100 rounded-xl text-slate-300 hover:text-primary hover:shadow-lg transition-all">
                        <Eye className="w-4 h-4" />
                     </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredAndSortedOrders.length === 0 && (
            <div className="py-24 text-center">
               <History className="w-12 h-12 text-slate-100 mx-auto mb-4" />
               <p className="text-slate-400 font-medium text-sm">No orders matching your criteria found.</p>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
};

export default AdminOrders;
