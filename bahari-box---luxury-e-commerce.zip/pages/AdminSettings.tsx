
import React from 'react';
import { useStore } from '../store';
import { Card, Button, Input, Badge } from '../components/UI';
import { 
  Globe, Shield, Bell, CreditCard, 
  Truck, Save, Info, RefreshCw, ChevronRight 
} from 'lucide-react';

const AdminSettings: React.FC = () => {
  const { siteSettings, updateSiteSettings, clearOrders, clearProducts } = useStore();

  const handleFlushOrders = () => {
    if (window.confirm("WARNING: This will permanently delete ALL order records. This action is irreversible. Continue?")) {
      clearOrders();
      alert("Order history has been successfully purged.");
    }
  };

  const handleWipeProducts = () => {
    if (window.confirm("WARNING: This will remove ALL products from the store. Customers will see an empty catalog. Continue?")) {
      clearProducts();
      alert("Inventory has been cleared.");
    }
  };

  return (
    <div className="space-y-12">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-4xl font-brand font-bold text-slate-900 italic">Site Controls</h1>
          <p className="text-slate-500 font-medium">Global configuration and brand identity settings.</p>
        </div>
        <Button className="h-14 px-10 bg-primary text-white text-xs font-black uppercase tracking-widest rounded-2xl shadow-xl shadow-primary/20">
          <Save className="w-4 h-4 mr-3" /> Save All Configuration
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Navigation Sidebar for Settings */}
        <div className="lg:col-span-1 space-y-4">
           {[
             { label: 'General Configuration', icon: Globe, active: true },
             { label: 'Security & Access', icon: Shield, active: false },
             { label: 'Shipping & Logistics', icon: Truck, active: false },
             { label: 'Payment Integration', icon: CreditCard, active: false },
             { label: 'System Notifications', icon: Bell, active: false },
           ].map(item => (
             <button key={item.label} className={`w-full flex items-center justify-between p-6 rounded-[2rem] transition-all ${item.active ? 'bg-white shadow-xl text-primary font-black border border-slate-100' : 'text-slate-400 hover:text-slate-600'}`}>
                <div className="flex items-center gap-4 text-sm uppercase tracking-widest font-bold">
                   <item.icon className={`w-5 h-5 ${item.active ? 'text-accent' : ''}`} />
                   {item.label}
                </div>
                {item.active && <ChevronRight className="w-4 h-4" />}
             </button>
           ))}
        </div>

        {/* Settings Content Area */}
        <div className="lg:col-span-2 space-y-8">
           <Card className="p-10 border-none shadow-xl shadow-slate-200/50 rounded-[2.5rem] space-y-10">
              <div className="space-y-2">
                 <h3 className="text-xl font-black text-slate-900">General Identity</h3>
                 <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Global storefront appearance</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                 <div className="space-y-3">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Storefront Currency</label>
                    <select className="w-full h-14 px-6 bg-slate-50 border-none rounded-2xl text-sm font-bold focus:ring-2 focus:ring-accent transition-all">
                       <option>৳ Bangladeshi Taka (BDT)</option>
                       <option>$ US Dollar (USD)</option>
                       <option>€ Euro (EUR)</option>
                    </select>
                 </div>
                 <div className="space-y-3">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Global Tax Rate (%)</label>
                    <Input defaultValue="15" className="h-14 px-6 bg-slate-50 border-none rounded-2xl text-sm font-bold" />
                 </div>
                 <div className="md:col-span-2 space-y-3">
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-500">Free Shipping Threshold</label>
                    <div className="relative">
                       <span className="absolute left-6 top-1/2 -translate-y-1/2 font-black text-slate-400">৳</span>
                       <Input 
                         value={siteSettings.freeShippingThreshold} 
                         onChange={e => updateSiteSettings({ freeShippingThreshold: parseInt(e.target.value) })}
                         className="h-14 pl-12 pr-6 bg-slate-50 border-none rounded-2xl text-sm font-bold" 
                       />
                    </div>
                 </div>
              </div>

              <div className="p-6 bg-blue-50 rounded-3xl border border-blue-100 flex gap-6 items-start">
                 <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-blue-600 shadow-sm flex-shrink-0">
                    <Info className="w-6 h-6" />
                 </div>
                 <div className="space-y-2">
                    <h4 className="text-xs font-black text-blue-900 uppercase tracking-widest">Auto-Optimization</h4>
                    <p className="text-sm text-blue-700/70 font-medium leading-relaxed">System is currently caching catalog imagery for faster response times. Last synced 4 minutes ago.</p>
                    <button className="text-[10px] font-black uppercase tracking-widest text-blue-600 flex items-center gap-2 mt-2">
                       <RefreshCw className="w-3 h-3" /> Force Sync Now
                    </button>
                 </div>
              </div>
           </Card>

           <Card className="p-10 border-none shadow-xl shadow-slate-200/50 rounded-[2.5rem] bg-red-50/30">
              <div className="space-y-2 mb-8">
                 <h3 className="text-xl font-black text-red-900">Danger Zone</h3>
                 <p className="text-xs text-red-400 font-bold uppercase tracking-widest">Irreversible System Actions</p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                 <Button 
                   variant="danger" 
                   onClick={handleFlushOrders}
                   className="h-14 px-10 rounded-2xl font-black uppercase tracking-widest text-[10px] shadow-xl shadow-red-200"
                 >
                    Flush Entire Order History
                 </Button>
                 <Button 
                   variant="outline" 
                   onClick={handleWipeProducts}
                   className="h-14 px-10 rounded-2xl font-black uppercase tracking-widest text-[10px] bg-white border-red-100 text-red-600"
                 >
                    Wipe Entire Catalog
                 </Button>
              </div>
           </Card>
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;
