
import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, Package, Users, Search, Menu, X, 
  ArrowLeftRight, Bell, Settings, HelpCircle, LogOut,
  ChevronRight, PlusCircle, ExternalLink, Globe,
  ShoppingBag, User, Shield, Zap, Activity, Cpu,
  UserCircle, Heart, Box, LogIn
} from 'lucide-react';
import { useStore } from '../store';
import { Button } from './UI';

// Exporting Logo for reuse
export const Logo: React.FC<{ className?: string; color?: string }> = ({ className = "w-10 h-10", color = "#2A1B28" }) => (
  <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 50 L50 65 L80 50 L50 35 Z" fill={color} opacity="0.1" />
    <path d="M20 50 L20 75 L50 90 L80 75 L80 50" stroke={color} strokeWidth="2.5" />
    <path d="M50 90 L50 65" stroke={color} strokeWidth="2.5" />
    <path d="M20 50 L50 65 L80 50" stroke={color} strokeWidth="2.5" />
    <path d="M20 50 L50 35 L80 50 L50 65 Z" stroke={color} strokeWidth="2.5" />
    <path d="M20 50 L15 30 L45 15 L50 35" stroke={color} strokeWidth="2.5" fill="white" />
  </svg>
);

export const PublicLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { cart, siteSettings, customer, isCustomerAuthenticated, customerLogout } = useStore();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogout = () => {
    customerLogout();
    setUserMenuOpen(false);
    navigate('/');
  };

  if (siteSettings.isMaintenanceMode) {
    return (
      <div className="h-screen bg-primary flex flex-col items-center justify-center p-6 text-center">
        <Logo className="w-20 h-20 mb-8" color="white" />
        <h1 className="font-brand text-4xl text-white mb-4">Curating Excellence</h1>
        <p className="text-white/50 max-w-md">We are currently updating our collections. Please return shortly for a refined gifting experience.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#FCFBFC]">
      {/* Announcement Bar */}
      <div className="bg-primary text-white text-[9px] font-black uppercase tracking-[0.4em] py-3 text-center px-4 relative z-[60]">
        {siteSettings.announcementBar} — <Link to="/products" className="underline underline-offset-4 hover:text-accent transition-colors">Browse Catalog</Link>
      </div>

      <nav 
        className={`fixed top-[42px] inset-x-0 z-50 transition-all duration-700 ${
          isScrolled 
            ? 'bg-white/80 backdrop-blur-xl py-4 shadow-[0_20px_40px_-15px_rgba(0,0,0,0.05)] border-b border-slate-100' 
            : 'bg-transparent py-10'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="flex justify-between items-center">
            {/* Left Desktop Nav */}
            <div className="hidden lg:flex items-center gap-12">
              <Link to="/products" className={`text-[10px] font-black uppercase tracking-[0.3em] transition-colors ${isScrolled ? 'text-primary' : 'text-primary/70'} hover:text-accent`}>The Collections</Link>
              <Link to="/products" className={`text-[10px] font-black uppercase tracking-[0.3em] transition-colors ${isScrolled ? 'text-primary' : 'text-primary/70'} hover:text-accent`}>Our Story</Link>
            </div>

            {/* Logo Center */}
            <Link to="/" className="flex flex-col items-center group relative lg:absolute lg:left-1/2 lg:-translate-x-1/2">
              <div className={`transition-all duration-700 flex flex-col items-center ${isScrolled ? 'scale-90' : 'scale-110'}`}>
                <Logo className="w-10 h-10 mb-1" />
                <span className="font-brand font-bold text-3xl tracking-tight text-primary">Bahari Box</span>
              </div>
            </Link>
            
            {/* Right Nav Icons */}
            <div className="flex items-center gap-2 sm:gap-6">
              {/* Customer Login Corner */}
              <div className="relative">
                <button 
                  onClick={() => isCustomerAuthenticated ? setUserMenuOpen(!userMenuOpen) : navigate('/login')}
                  className={`flex items-center gap-2 p-2 transition-all duration-300 ${isScrolled ? 'text-primary' : 'text-primary/70'} hover:text-accent group`}
                >
                  {isCustomerAuthenticated ? (
                    <div className="flex items-center gap-3">
                      <span className="hidden sm:block text-[9px] font-black uppercase tracking-widest text-primary/60 group-hover:text-accent transition-colors">
                        Hello, {customer?.name.split(' ')[0]}
                      </span>
                      <div className="w-8 h-8 rounded-full border border-slate-200 flex items-center justify-center bg-white shadow-sm overflow-hidden group-hover:border-accent transition-colors">
                        <User className="w-4 h-4" />
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                       <span className="hidden sm:block text-[9px] font-black uppercase tracking-widest">Sign In</span>
                       <UserCircle className="w-6 h-6 stroke-[1.5]" />
                    </div>
                  )}
                </button>

                {/* Account Dropdown */}
                {userMenuOpen && (
                  <div className="absolute top-full right-0 mt-4 w-64 bg-white shadow-[0_30px_60px_-15px_rgba(0,0,0,0.1)] border border-slate-100 p-6 animate-in fade-in slide-in-from-top-4 duration-300 rounded-2xl z-[100]">
                    <div className="mb-6 border-b border-slate-50 pb-4">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Circle Member</p>
                      <h4 className="font-brand font-bold text-lg text-primary">{customer?.name}</h4>
                    </div>
                    <nav className="space-y-4">
                      <Link to="/account" className="flex items-center gap-3 text-xs font-bold text-slate-500 hover:text-accent transition-colors" onClick={() => setUserMenuOpen(false)}>
                        <Box className="w-4 h-4" /> My Collections
                      </Link>
                      <Link to="/account" className="flex items-center gap-3 text-xs font-bold text-slate-500 hover:text-accent transition-colors" onClick={() => setUserMenuOpen(false)}>
                        <Heart className="w-4 h-4" /> Wishlist
                      </Link>
                      <Link to="/account" className="flex items-center gap-3 text-xs font-bold text-slate-500 hover:text-accent transition-colors" onClick={() => setUserMenuOpen(false)}>
                        <Settings className="w-4 h-4" /> Preferences
                      </Link>
                      <div className="pt-4 border-t border-slate-50">
                        <button onClick={handleLogout} className="flex items-center gap-3 text-xs font-bold text-red-400 hover:text-red-600 transition-colors w-full">
                          <LogOut className="w-4 h-4" /> Sign Out
                        </button>
                      </div>
                    </nav>
                  </div>
                )}
              </div>

              <Link to="/cart" className="relative p-2 text-primary transition-transform hover:scale-110 active:scale-95 group">
                <ShoppingBag className="w-6 h-6 stroke-[1.5] group-hover:text-accent transition-colors" />
                {cart.length > 0 && (
                  <span className="absolute top-1 right-1 bg-accent text-white text-[9px] font-black w-4.5 h-4.5 flex items-center justify-center rounded-full border-2 border-white shadow-lg animate-pop">
                    {cart.reduce((a, b) => a + b.quantity, 0)}
                  </span>
                )}
              </Link>
              <button className="lg:hidden p-2 text-primary" onClick={() => setMobileMenuOpen(true)}>
                <Menu className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 z-[100] bg-white p-10 flex flex-col animate-in slide-in-from-right duration-700 ease-out">
            <div className="flex justify-end mb-16">
              <button onClick={() => setMobileMenuOpen(false)} className="p-3 text-primary bg-slate-50 rounded-full"><X className="w-8 h-8" /></button>
            </div>
            <nav className="flex flex-col gap-10 text-center">
              <Link to="/" className="text-5xl font-brand font-bold text-primary italic" onClick={() => setMobileMenuOpen(false)}>Home</Link>
              <Link to="/products" className="text-5xl font-brand font-bold text-primary italic" onClick={() => setMobileMenuOpen(false)}>Catalog</Link>
              {isCustomerAuthenticated ? (
                <Link to="/account" className="text-5xl font-brand font-bold text-primary italic" onClick={() => setMobileMenuOpen(false)}>Profile</Link>
              ) : (
                <Link to="/login" className="text-5xl font-brand font-bold text-primary italic" onClick={() => setMobileMenuOpen(false)}>Sign In</Link>
              )}
              <Link to="/cart" className="text-5xl font-brand font-bold text-primary italic" onClick={() => setMobileMenuOpen(false)}>Your Box</Link>
              <div className="pt-20 border-t border-slate-100 flex flex-col items-center gap-8">
                <Link to="/admin/login" className="text-xs font-black uppercase tracking-[0.4em] text-slate-300 flex items-center gap-2" onClick={() => setMobileMenuOpen(false)}>
                  <Shield className="w-4 h-4" /> Merchant Entry
                </Link>
              </div>
            </nav>
          </div>
        )}
      </nav>

      <main className="flex-grow pt-[120px]">{children}</main>

      <footer className="bg-white border-t border-slate-100 pt-32 pb-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-20 mb-24">
            <div className="md:col-span-2 space-y-10">
              <div className="flex items-center gap-4">
                <Logo className="w-12 h-12" />
                <span className="font-brand font-bold text-3xl text-primary tracking-tight">Bahari Box</span>
              </div>
              <p className="text-slate-400 max-w-sm leading-relaxed font-light italic text-lg">
                "Curating joy through artisanal excellence. We believe every gift should be a masterpiece of thoughtfulness."
              </p>
            </div>
            <div className="space-y-8">
              <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-primary">Experience</h4>
              <nav className="flex flex-col gap-4">
                <Link to="/products" className="text-sm text-slate-500 hover:text-accent transition-colors font-light">The Catalog</Link>
                <Link to="/login" className="text-sm text-slate-500 hover:text-accent transition-colors font-light">Join the Circle</Link>
                <Link to="/" className="text-sm text-slate-500 hover:text-accent transition-colors font-light">Gifting Guide</Link>
              </nav>
            </div>
            <div className="space-y-8">
              <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-primary">Support</h4>
              <nav className="flex flex-col gap-4">
                <Link to="/" className="text-sm text-slate-500 hover:text-accent transition-colors font-light">Shipping Policy</Link>
                <Link to="/admin/login" className="text-sm text-slate-300 hover:text-primary transition-colors font-bold underline underline-offset-4 flex items-center gap-2">
                  <Shield className="w-3.5 h-3.5" /> Merchant Portal
                </Link>
              </nav>
            </div>
          </div>
          <div className="pt-16 border-t border-slate-50 flex flex-col md:flex-row justify-between items-center gap-8">
            <p className="text-slate-300 text-[9px] font-black uppercase tracking-[0.3em]">© 2024 Bahari Box. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export const AdminLayout: React.FC<{ children: React.ReactNode; onLogout: () => void }> = ({ children, onLogout }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const navItems = [
    { label: 'Control Center', icon: LayoutDashboard, path: '/admin' },
    { label: 'Inventory', icon: Package, path: '/admin/products' },
    { label: 'Logistics', icon: ArrowLeftRight, path: '/admin/orders' },
    { label: 'Site Controls', icon: Settings, path: '/admin/settings' },
  ];

  const handleLogout = () => {
    onLogout();
    navigate('/');
  };

  return (
    <div className="min-h-screen flex bg-[#F0F2F5]">
      {/* High-End Pro Sidebar */}
      <aside className="w-[280px] bg-[#0A0D14] text-slate-300 hidden lg:flex flex-col fixed inset-y-0 z-50 border-r border-white/5">
        <div className="p-8 flex items-center gap-3">
          <div className="bg-gradient-to-br from-primary to-accent p-2 rounded-xl shadow-lg shadow-primary/20">
            <Logo className="w-8 h-8" color="#FFFFFF" />
          </div>
          <div>
            <span className="font-brand font-bold text-2xl text-white block leading-none">Command</span>
            <span className="text-[9px] uppercase tracking-[0.2em] font-black text-slate-500">Center v3.0</span>
          </div>
        </div>
        
        <div className="flex-grow flex flex-col px-4 pt-4">
          <nav className="space-y-2">
            {navItems.map((item) => (
              <Link
                key={item.label}
                to={item.path}
                className={`flex items-center justify-between group px-5 py-4 rounded-2xl font-semibold transition-all duration-300 ${
                  location.pathname === item.path 
                    ? 'bg-white/10 text-white shadow-[inset_0_0_20px_rgba(255,255,255,0.05)] border border-white/10' 
                    : 'text-slate-500 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-4">
                  <item.icon className={`w-5 h-5 transition-colors ${location.pathname === item.path ? 'text-accent' : 'text-slate-600 group-hover:text-white'}`} />
                  {item.label}
                </div>
                {location.pathname === item.path && <div className="w-1.5 h-1.5 rounded-full bg-accent shadow-[0_0_10px_#C5A059]"></div>}
              </Link>
            ))}
          </nav>

          {/* System Health Widget */}
          <div className="mt-auto mb-8 mx-2 bg-white/5 rounded-3xl p-6 border border-white/5 space-y-4">
             <div className="flex items-center justify-between">
                <span className="text-[9px] font-black uppercase tracking-widest text-slate-500">System Health</span>
                <span className="flex h-2 w-2 relative">
                   <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                   <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </span>
             </div>
             <div className="space-y-3">
                <div className="flex justify-between items-center text-[10px] font-bold">
                   <span className="text-slate-400 flex items-center gap-2"><Activity className="w-3 h-3" /> API Latency</span>
                   <span className="text-white">24ms</span>
                </div>
                <div className="flex justify-between items-center text-[10px] font-bold">
                   <span className="text-slate-400 flex items-center gap-2"><Cpu className="w-3 h-3" /> Node Load</span>
                   <span className="text-white">12%</span>
                </div>
             </div>
          </div>
        </div>

        <div className="p-4 border-t border-white/5 bg-white/2">
          <button 
            onClick={handleLogout}
            className="flex items-center gap-4 px-6 py-5 text-slate-500 hover:text-red-400 transition-all text-xs font-black uppercase tracking-widest w-full"
          >
            <LogOut className="w-4 h-4" /> End Session
          </button>
        </div>
      </aside>

      <div className="lg:ml-[280px] flex-grow flex flex-col">
        <header className="bg-white/60 backdrop-blur-2xl h-24 border-b border-slate-200 px-12 flex items-center justify-between sticky top-0 z-40">
          <div className="flex items-center gap-6 flex-grow max-w-xl">
             <div className="relative w-full group">
               <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4 group-focus-within:text-primary transition-colors" />
               <input 
                 type="text" 
                 placeholder="Command search..." 
                 className="w-full h-12 bg-slate-100/50 border-none rounded-2xl pl-12 pr-4 text-sm focus:ring-2 focus:ring-primary/10 focus:bg-white transition-all font-medium"
               />
             </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button className="w-12 h-12 flex items-center justify-center text-slate-400 hover:text-primary hover:bg-white hover:shadow-xl rounded-2xl transition-all relative group">
              <Bell className="w-5 h-5" />
              <span className="absolute top-3 right-3 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white shadow-sm"></span>
            </button>
            <div className="h-8 w-[1px] bg-slate-200 mx-2"></div>
            <div className="flex items-center gap-4 pl-2">
               <div className="text-right hidden sm:block">
                  <p className="text-xs font-black text-slate-900 leading-tight">Admin Curator</p>
                  <p className="text-[10px] text-accent font-bold uppercase tracking-tighter">Root Access</p>
               </div>
               <div className="w-12 h-12 rounded-2xl bg-primary flex items-center justify-center text-white font-black shadow-xl shadow-primary/20">
                 AC
               </div>
            </div>
          </div>
        </header>

        <main className="p-12 min-h-screen">
          <div className="max-w-[1600px] mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};
