
import { GoogleGenAI } from "@google/genai";

export const generateProductDescription = async (productName: string, features: string): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Write a compelling, professional, and SEO-friendly product description for a product named "${productName}". Key features to include: ${features}. Keep it under 150 words.`,
    });
    return response.text || "Failed to generate description.";
  } catch (error) {
    console.error("AI Generation Error:", error);
    return "Error generating description. Please try again.";
  }
};
