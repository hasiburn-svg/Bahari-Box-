
import React, { createContext, useContext, useState } from 'react';
import { Product, Order, CartItem, DashboardStats } from './types';
import { MOCK_PRODUCTS, MOCK_ORDERS } from './constants';

interface SiteSettings {
  announcementBar: string;
  isMaintenanceMode: boolean;
  freeShippingThreshold: number;
  currency: string;
}

interface Customer {
  name: string;
  email: string;
  joinedDate: string;
}

interface StoreContextType {
  products: Product[];
  orders: Order[];
  cart: CartItem[];
  siteSettings: SiteSettings;
  customer: Customer | null;
  isCustomerAuthenticated: boolean;
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (id: string) => void;
  clearProducts: () => void;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  clearOrders: () => void;
  addToCart: (product: Product) => void;
  updateCartQuantity: (productId: string, delta: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  placeOrder: (customerDetails: { name: string; email: string }, total: number, paymentMethod?: string, transactionId?: string) => string;
  getDashboardStats: () => DashboardStats;
  updateSiteSettings: (settings: Partial<SiteSettings>) => void;
  customerLogin: (email: string, name: string) => void;
  customerLogout: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [orders, setOrders] = useState<Order[]>(MOCK_ORDERS);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [siteSettings, setSiteSettings] = useState<SiteSettings>({
    announcementBar: "Complimentary priority shipping on all orders over ৳1,500",
    isMaintenanceMode: false,
    freeShippingThreshold: 1500,
    currency: "৳"
  });

  // Customer State
  const [customer, setCustomer] = useState<Customer | null>(() => {
    const saved = localStorage.getItem('bahari_customer');
    return saved ? JSON.parse(saved) : null;
  });
  const isCustomerAuthenticated = !!customer;

  const customerLogin = (email: string, name: string) => {
    const newCustomer = { email, name, joinedDate: new Date().toISOString() };
    setCustomer(newCustomer);
    localStorage.setItem('bahari_customer', JSON.stringify(newCustomer));
  };

  const customerLogout = () => {
    setCustomer(null);
    localStorage.removeItem('bahari_customer');
  };

  const addProduct = (p: Omit<Product, 'id'>) => {
    const newProduct = { ...p, id: Math.random().toString(36).substr(2, 9) };
    setProducts([...products, newProduct]);
  };

  const updateProduct = (updated: Product) => {
    setProducts(products.map(p => p.id === updated.id ? updated : p));
  };

  const deleteProduct = (id: string) => {
    setProducts(products.filter(p => p.id !== id));
  };

  const clearProducts = () => {
    setProducts([]);
  };

  const updateOrderStatus = (orderId: string, status: Order['status']) => {
    setOrders(orders.map(o => o.id === orderId ? { ...o, status } : o));
  };

  const clearOrders = () => {
    setOrders([]);
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const updateCartQuantity = (productId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === productId) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const clearCart = () => setCart([]);

  const placeOrder = (customerDetails: { name: string; email: string }, total: number, paymentMethod?: string, transactionId?: string) => {
    const orderId = `ORD-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;
    const newOrder: Order = {
      id: orderId,
      customerName: customerDetails.name,
      customerEmail: customerDetails.email,
      total,
      status: 'Pending',
      date: new Date().toISOString().split('T')[0],
      items: cart.map(item => ({
        productId: item.id,
        name: item.name,
        quantity: item.quantity,
        price: item.price
      })),
      paymentMethod,
      transactionId
    };
    setOrders([newOrder, ...orders]);
    clearCart();
    return orderId;
  };

  const updateSiteSettings = (settings: Partial<SiteSettings>) => {
    setSiteSettings(prev => ({ ...prev, ...settings }));
  };

  const getDashboardStats = (): DashboardStats => {
    const totalSales = orders.reduce((acc, o) => acc + o.total, 0);
    const recentSales = [
      { date: 'Mon', amount: 4500 },
      { date: 'Tue', amount: 3200 },
      { date: 'Wed', amount: 6000 },
      { date: 'Thu', amount: 2000 },
      { date: 'Fri', amount: 8000 },
      { date: 'Sat', amount: 12000 },
      { date: 'Sun', amount: 9500 },
    ];
    return {
      totalSales,
      totalOrders: orders.length,
      totalProducts: products.length,
      recentSales
    };
  };

  return (
    <StoreContext.Provider value={{
      products, orders, cart, siteSettings, customer, isCustomerAuthenticated,
      addProduct, updateProduct, deleteProduct, clearProducts,
      updateOrderStatus, clearOrders, addToCart, updateCartQuantity, removeFromCart, clearCart,
      placeOrder, getDashboardStats, updateSiteSettings, customerLogin, customerLogout
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) throw new Error('useStore must be used within a StoreProvider');
  return context;
};
